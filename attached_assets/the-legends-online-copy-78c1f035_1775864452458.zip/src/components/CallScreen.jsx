import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { PhoneOff, Mic, MicOff, Video, VideoOff } from 'lucide-react';

export default function CallScreen({ call, isVideo, calleeName, onEnd }) {
  const localRef = useRef(null);
  const remoteRef = useRef(null);
  const [muted, setMuted] = useState(false);
  const [videoOff, setVideoOff] = useState(false);
  const [status, setStatus] = useState('connecting'); // connecting | active | ended

  useEffect(() => {
    if (!call) return;

    call.onEstablished = () => setStatus('active');
    call.onConnected = () => {
      setStatus('active');
      if (isVideo) {
        call.setLocalMediaView(localRef.current);
        call.setRemoteMediaView(remoteRef.current);
      }
    };
    call.onEnded = () => {
      setStatus('ended');
      setTimeout(onEnd, 1000);
    };
    call.onRemoteAudioSettingsChanged = () => {};
    call.onRemoteVideoSettingsChanged = () => {};

    // If incoming, accept it
    if (call.isIncoming) {
      call.accept({ callOption: { audioEnabled: true, videoEnabled: isVideo } });
    }

    return () => {
      if (call && !call.isEnded) call.end();
    };
  }, [call]);

  const toggleMute = () => {
    if (muted) call.unmuteMicrophone();
    else call.muteMicrophone();
    setMuted(m => !m);
  };

  const toggleVideo = () => {
    if (videoOff) call.startVideo();
    else call.stopVideo();
    setVideoOff(v => !v);
  };

  const endCall = () => {
    call.end();
    onEnd();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[600] flex flex-col items-center justify-center bg-black/90 backdrop-blur-xl"
    >
      {/* Video views */}
      {isVideo && (
        <div className="relative w-full max-w-lg aspect-video rounded-2xl overflow-hidden bg-gray-900 mb-6">
          <video ref={remoteRef} autoPlay playsInline className="w-full h-full object-cover" />
          <video ref={localRef} autoPlay playsInline muted className="absolute bottom-3 right-3 w-28 h-20 rounded-xl object-cover border border-white/20" />
        </div>
      )}

      {/* Avatar for voice calls */}
      {!isVideo && (
        <div className="w-24 h-24 rounded-full bg-primary/20 border-2 border-primary/50 flex items-center justify-center text-3xl font-bold text-primary mb-4">
          {calleeName?.charAt(0)?.toUpperCase()}
        </div>
      )}

      <p className="text-lg font-semibold text-white mb-1">{calleeName}</p>
      <p className="text-sm text-muted-foreground mb-8">
        {status === 'connecting' ? 'Connexion...' : status === 'active' ? 'En cours...' : 'Appel terminé'}
      </p>

      {/* Controls */}
      <div className="flex items-center gap-4">
        <button onClick={toggleMute}
          className={`p-4 rounded-full border transition-all ${muted ? 'bg-white/20 border-white/30 text-white' : 'bg-white/10 border-white/10 text-muted-foreground'}`}>
          {muted ? <MicOff size={22} /> : <Mic size={22} />}
        </button>

        {isVideo && (
          <button onClick={toggleVideo}
            className={`p-4 rounded-full border transition-all ${videoOff ? 'bg-white/20 border-white/30 text-white' : 'bg-white/10 border-white/10 text-muted-foreground'}`}>
            {videoOff ? <VideoOff size={22} /> : <Video size={22} />}
          </button>
        )}

        <button onClick={endCall}
          className="p-4 rounded-full bg-red-500 hover:bg-red-600 text-white transition-all">
          <PhoneOff size={22} />
        </button>
      </div>
    </motion.div>
  );
}