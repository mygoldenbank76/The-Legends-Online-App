import { motion } from 'framer-motion';
import { Phone, PhoneOff, Video } from 'lucide-react';

export default function IncomingCallModal({ call, onAccept, onDecline }) {
  const callerName = call?.caller?.nickname || call?.caller?.userId || 'Inconnu';
  const isVideo = call?.isVideoCall;

  return (
    <motion.div
      initial={{ opacity: 0, y: -40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -40 }}
      className="fixed top-4 left-1/2 -translate-x-1/2 z-[700] w-80 glass-strong rounded-2xl border border-white/10 p-4 shadow-2xl"
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-xl font-bold text-primary">
          {callerName.charAt(0).toUpperCase()}
        </div>
        <div>
          <p className="font-semibold text-sm">{callerName}</p>
          <p className="text-xs text-muted-foreground">{isVideo ? 'Appel vidéo entrant...' : 'Appel vocal entrant...'}</p>
        </div>
      </div>
      <div className="flex gap-3">
        <button onClick={onDecline}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 transition-all text-sm font-medium">
          <PhoneOff size={16} /> Refuser
        </button>
        <button onClick={onAccept}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-green-500/10 border border-green-500/30 text-green-400 hover:bg-green-500/20 transition-all text-sm font-medium">
          {isVideo ? <Video size={16} /> : <Phone size={16} />} Accepter
        </button>
      </div>
    </motion.div>
  );
}