import React from 'react';
import { motion } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';

export default function ConversationList({ conversations, selected, onSelect, user, isDm, allUsers = [] }) {
  const resolveIdentifier = (idOrEmail) => {
    if (!idOrEmail) return null;
    const byId = allUsers.find(u => u.id === idOrEmail);
    if (byId) return byId.full_name || byId.email?.split('@')[0] || null;
    const byEmail = allUsers.find(u => u.email === idOrEmail);
    if (byEmail) return byEmail.full_name || byEmail.email?.split('@')[0] || null;
    if (idOrEmail.includes('@')) return idOrEmail.split('@')[0];
    return null;
  };

  const getDisplayName = (conv) => {
    if (isDm && conv.member_emails?.length > 0) {
      const otherRaw = conv.member_emails.find(e => e !== user?.email && e !== user?.id);
      if (otherRaw) {
        const resolved = resolveIdentifier(otherRaw);
        if (resolved) return resolved;
      }
    }
    // If name contains '&', extract the part that doesn't match the current user
    if (isDm && conv.name?.includes('&')) {
      const parts = conv.name.split('&').map(p => p.trim());
      const currentPrefix = user?.email?.split('@')[0];
      const currentName = user?.full_name;
      const other = parts.find(p => p !== currentPrefix && p !== currentName);
      if (other) return other;
    }
    // If name looks like a bare ID (hex, no @), try to resolve from members
    if (conv.name && /^[0-9a-f]{20,}$/i.test(conv.name)) {
      if (conv.member_emails?.length > 0) {
        const otherRaw = conv.member_emails.find(e => e !== user?.email && e !== user?.id) || conv.member_emails[0];
        const resolved = resolveIdentifier(otherRaw);
        if (resolved) return resolved;
      }
    }
    return conv.name;
  };

  const getAvatar = (conv) => {
    const name = getDisplayName(conv);
    return name?.charAt(0)?.toUpperCase() || '?';
  };

  return (
    <div className="flex-1 overflow-y-auto py-2 px-2" style={{scrollbarWidth: 'none', msOverflowStyle: 'none'}}>
      {conversations.map((conv, i) => {
        const active = selected?.id === conv.id;
        return (
          <motion.button
            key={conv.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.03 }}
            onClick={() => onSelect(conv)}
            className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all mb-1 text-left ${active ? 'bg-primary/15 border border-primary/20' : 'hover:bg-white/5 border border-transparent'}`}
          >
            {/* Avatar */}
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold shrink-0 ${active ? 'bg-primary/20 text-primary' : 'bg-white/8 text-muted-foreground'}`}>
              {conv.avatar_url ? (
                <img src={conv.avatar_url} className="w-full h-full rounded-xl object-cover" alt="" />
              ) : (
                getAvatar(conv)
              )}
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <p className={`text-sm font-semibold truncate ${active ? 'text-foreground' : 'text-foreground/90'}`}>
                  {getDisplayName(conv)}
                </p>
                {conv.last_message_at && (
                  <p className="text-[10px] text-muted-foreground shrink-0">
                    {formatDistanceToNow(new Date(conv.last_message_at), { addSuffix: false, locale: fr })}
                  </p>
                )}
              </div>
              {conv.last_message && (
                <p className="text-xs text-muted-foreground truncate mt-0.5">
                  {conv.last_message_sender && <span className="font-medium">{conv.last_message_sender}: </span>}
                  {conv.last_message}
                </p>
              )}
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}