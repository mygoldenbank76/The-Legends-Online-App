import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { X, MessageCircle, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function UserProfileModal({ targetUser, currentUser, onClose, onDmCreated }) {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  if (!targetUser) return null;

  const displayName = targetUser.name || targetUser.email?.split('@')[0] || 'Utilisateur';
  const initial = displayName.charAt(0).toUpperCase();

  const handleSendDm = async () => {
    setLoading(true);
    try {
      // Check if a direct conversation already exists
      const existing = await base44.entities.Conversation.filter({ type: 'direct' }, '-last_message_at', 100);
      const found = existing.find(c =>
        c.member_emails?.includes(currentUser.email) &&
        c.member_emails?.includes(targetUser.email)
      );

      let conv = found;
       if (!conv) {
         conv = await base44.entities.Conversation.create({
           name: `${currentUser.full_name || currentUser.email.split('@')[0]} & ${displayName}`,
           type: 'direct',
           member_emails: [currentUser.email, targetUser.email],
           member_ids: [currentUser.id, targetUser.id || ''],
         });
       }

       if (onDmCreated) {
         onDmCreated(conv);
       } else {
         localStorage.setItem('dm_open_conv_id', conv.id);
         navigate('/DirectMessages');
       }
       onClose();
    } catch {
      toast.error('Erreur lors de l\'ouverture du message privé');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="relative glass-strong rounded-2xl border border-white/10 p-6 max-w-xs w-full z-10 flex flex-col items-center gap-4 text-center"
        onClick={e => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-3 right-3 p-1.5 rounded-lg hover:bg-white/10 text-muted-foreground transition-all">
          <X size={16} />
        </button>

        {/* Avatar */}
        <div className="w-16 h-16 rounded-2xl bg-primary/20 border border-primary/30 flex items-center justify-center text-2xl font-bold text-primary">
          {initial}
        </div>

        {/* Info */}
        <div>
          <p className="font-bold text-base text-foreground">{displayName}</p>
        </div>

        {/* DM button — only if not the current user */}
        {targetUser.email !== currentUser?.email && (
          <button
            onClick={handleSendDm}
            disabled={loading}
            className="w-full py-3 rounded-xl border border-primary/30 bg-primary/15 hover:bg-primary/25 text-sm font-semibold text-primary transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            ) : (
              <MessageCircle size={16} />
            )}
            Envoyer un message privé
          </button>
        )}
      </motion.div>
    </div>
  );
}