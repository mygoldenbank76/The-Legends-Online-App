import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldAlert, RefreshCw, LogOut } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const INACTIVE_TIMEOUT = 30 * 60 * 1000; // 30 minutes
const WARNING_BEFORE = 60 * 1000;        // avertissement 1 minute avant

export default function SessionTimeout() {
  const [showWarning, setShowWarning] = useState(false);
  const [countdown, setCountdown] = useState(60);
  const inactivityTimer = useRef(null);
  const countdownTimer = useRef(null);

  const logout = useCallback(() => {
    base44.auth.logout();
  }, []);

  const resetSession = useCallback(() => {
    setShowWarning(false);
    setCountdown(60);
    clearTimeout(inactivityTimer.current);
    clearInterval(countdownTimer.current);
    startInactivityTimer();
  }, []);

  const startCountdown = useCallback(() => {
    setShowWarning(true);
    setCountdown(60);
    clearInterval(countdownTimer.current);
    countdownTimer.current = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(countdownTimer.current);
          logout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, [logout]);

  const startInactivityTimer = useCallback(() => {
    clearTimeout(inactivityTimer.current);
    inactivityTimer.current = setTimeout(() => {
      startCountdown();
    }, INACTIVE_TIMEOUT - WARNING_BEFORE);
  }, [startCountdown]);

  useEffect(() => {
    const events = ['mousemove', 'keydown', 'mousedown', 'touchstart', 'scroll', 'click'];

    const handleActivity = () => {
      if (!showWarning) resetSession();
    };

    startInactivityTimer();
    events.forEach(e => window.addEventListener(e, handleActivity, { passive: true }));

    return () => {
      clearTimeout(inactivityTimer.current);
      clearInterval(countdownTimer.current);
      events.forEach(e => window.removeEventListener(e, handleActivity));
    };
  }, [showWarning, resetSession, startInactivityTimer]);

  return (
    <AnimatePresence>
      {showWarning && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] flex items-center justify-center p-4"
        >
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 30 }}
            transition={{ type: 'spring', damping: 20, stiffness: 200 }}
            className="relative glass-strong rounded-2xl p-6 w-full max-w-sm border border-yellow-500/30 z-10"
          >
            {/* Icon */}
            <div className="flex justify-center mb-4">
              <div className="w-14 h-14 rounded-2xl bg-yellow-500/15 flex items-center justify-center">
                <ShieldAlert size={28} className="text-yellow-400" />
              </div>
            </div>

            {/* Title */}
            <h2 className="text-xl font-bold text-center text-foreground mb-1">
              Session inactive
            </h2>
            <p className="text-sm text-muted-foreground text-center mb-5">
              Vous allez être déconnecté automatiquement pour des raisons de sécurité.
            </p>

            {/* Countdown */}
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 rounded-full border-4 border-yellow-500/40 flex items-center justify-center relative">
                <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 80 80">
                  <circle cx="40" cy="40" r="36" fill="none" stroke="rgba(234,179,8,0.15)" strokeWidth="4" />
                  <circle
                    cx="40" cy="40" r="36" fill="none"
                    stroke="rgba(234,179,8,0.7)" strokeWidth="4"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 36}`}
                    strokeDashoffset={`${2 * Math.PI * 36 * (1 - countdown / 60)}`}
                    style={{ transition: 'stroke-dashoffset 1s linear' }}
                  />
                </svg>
                <span className="text-2xl font-bold text-yellow-400">{countdown}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col gap-2">
              <button
                onClick={resetSession}
                className="w-full py-3 rounded-xl border border-primary/30 bg-primary/10 hover:bg-primary/15 text-foreground font-semibold flex items-center justify-center gap-2 transition-all relative overflow-hidden"
              >
                <div className="absolute inset-0 animate-shimmer" />
                <RefreshCw size={16} />
                Rester connecté
              </button>
              <button
                onClick={logout}
                className="w-full py-3 rounded-xl border border-white/8 bg-white/5 hover:bg-red-500/10 hover:border-red-500/30 hover:text-red-400 text-muted-foreground font-medium flex items-center justify-center gap-2 transition-all"
              >
                <LogOut size={16} />
                Se déconnecter
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}