import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { X, Users, MessageSquare, Search, Check, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function NewConversationModal({ isOpen, onClose, type, user, onCreate }) {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState([]);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    if (isOpen) {
      base44.entities.User.list().then(us => setUsers(us.filter(u => u.email !== user?.email)));
      setSelected([]);
      setSearch('');
      setName('');
      setDescription('');
    }
  }, [isOpen, user]);

  const filtered = users.filter(u =>
    u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  const toggleUser = (u) => {
    if (type === 'direct') {
      setSelected([u]);
    } else {
      setSelected(p => p.find(s => s.id === u.id) ? p.filter(s => s.id !== u.id) : [...p, u]);
    }
  };

  const handleCreate = async () => {
    if (type === 'direct' && selected.length === 0) { toast.error('Sélectionnez au moins un utilisateur'); return; }
    if (type === 'group' && !name.trim()) { toast.error('Donnez un nom au groupe'); return; }
    setCreating(true);
    try {
      const allEmails = [user.email, ...selected.map(u => u.email)];
      const allIds = [user.id, ...selected.map(u => u.id)];
      const convName = type === 'direct'
        ? selected[0].full_name || selected[0].email.split('@')[0]
        : name.trim();

      // For DM, check if conversation already exists
      if (type === 'direct') {
        const existing = await base44.entities.Conversation.filter({ type: 'direct' });
        const found = existing.find(c =>
          c.member_emails?.includes(user.email) && c.member_emails?.includes(selected[0].email)
        );
        if (found) { onCreate(found); onClose(); return; }
      }

      const conv = await base44.entities.Conversation.create({
        name: convName,
        type,
        description,
        member_ids: allIds,
        member_emails: allEmails,
      });
      toast.success(type === 'group' ? 'Groupe créé !' : 'Conversation démarrée !');
      onCreate(conv);
      onClose();
    } catch {
      toast.error('Erreur lors de la création');
    } finally {
      setCreating(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-4 pb-16 md:pb-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
          <motion.div
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 60 }}
            className="relative glass-strong rounded-t-3xl md:rounded-2xl w-full md:max-w-md border border-white/10 z-10 max-h-[80vh] flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-white/8 shrink-0">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${type === 'group' ? 'bg-purple-500/10' : 'bg-cyan-500/10'}`}>
                  {type === 'group' ? <Users size={18} className="text-neon-purple" /> : <MessageSquare size={18} className="text-neon-cyan" />}
                </div>
                <h2 className="text-base font-bold gradient-text">
                  {type === 'group' ? 'Nouveau groupe' : 'Nouveau message'}
                </h2>
              </div>
              <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground">
                <X size={18} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
              {/* Group name */}
              {type === 'group' && (
                <div>
                  <label className="block text-xs text-muted-foreground mb-1.5 font-medium">Nom du groupe *</label>
                  <input value={name} onChange={e => setName(e.target.value)} placeholder="Ex: Équipe projet, Amis, ..."
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-primary/50 text-foreground placeholder-muted-foreground" />
                </div>
              )}

              {/* User search */}
              <div>
                <label className="block text-xs text-muted-foreground mb-1.5 font-medium">
                  {type === 'direct' ? 'Destinataire' : 'Membres (optionnel)'}
                </label>
                <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl px-3 py-2 mb-2 focus-within:border-primary/50">
                  <Search size={14} className="text-muted-foreground" />
                  <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher..."
                    className="bg-transparent text-sm outline-none flex-1 text-foreground placeholder-muted-foreground" />
                </div>

                {/* Selected chips */}
                {selected.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {selected.map(u => (
                      <div key={u.id} className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-primary/15 border border-primary/20 text-xs">
                        <p className="text-foreground">{u.full_name || u.email.split('@')[0]}</p>
                        <button onClick={() => toggleUser(u)} className="text-muted-foreground hover:text-foreground">
                          <X size={12} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* User list */}
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {filtered.map(u => {
                    const isSelected = selected.find(s => s.id === u.id);
                    return (
                      <button key={u.id} onClick={() => toggleUser(u)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-left ${isSelected ? 'bg-primary/15 border border-primary/20' : 'hover:bg-white/5 border border-transparent'}`}>
                        <div className="w-8 h-8 rounded-xl bg-white/8 flex items-center justify-center text-xs font-bold text-muted-foreground shrink-0">
                          {u.full_name?.charAt(0)?.toUpperCase() || u.email?.charAt(0)?.toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{u.full_name || u.email.split('@')[0]}</p>
                          <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                        </div>
                        {isSelected && <Check size={16} className="text-primary shrink-0" />}
                      </button>
                    );
                  })}
                  {filtered.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">Aucun utilisateur trouvé</p>}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-5 pb-5 pt-3 border-t border-white/8 shrink-0">
              <motion.button onClick={handleCreate} disabled={creating || (type === 'direct' && selected.length === 0)}
                whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}
                className="w-full py-3 rounded-xl bg-primary/15 border border-primary/30 hover:bg-primary/20 text-foreground font-semibold text-sm transition-all disabled:opacity-40 flex items-center justify-center gap-2">
                {creating ? <><Loader2 size={16} className="animate-spin" /> Création...</> : <>{type === 'group' ? <><Users size={16} /> Créer le groupe</> : <><MessageSquare size={16} /> Démarrer la conversation</>}</>}
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}