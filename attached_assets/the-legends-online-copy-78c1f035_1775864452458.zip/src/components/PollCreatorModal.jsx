import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Trash2, BarChart2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function PollCreatorModal({ isOpen, onClose, conversation, user, onPollCreated }) {
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);
  const [anonymous, setAnonymous] = useState(true);
  const [multiple, setMultiple] = useState(false);
  const [isQuiz, setIsQuiz] = useState(false);
  const [quizAnswer, setQuizAnswer] = useState(0);
  const [creating, setCreating] = useState(false);

  const reset = () => {
    setQuestion('');
    setOptions(['', '']);
    setAnonymous(true);
    setMultiple(false);
    setIsQuiz(false);
    setQuizAnswer(0);
  };

  const handleClose = () => { reset(); onClose(); };

  const addOption = () => {
    if (options.length < 12) setOptions(p => [...p, '']);
  };

  const removeOption = (i) => {
    if (options.length <= 2) return;
    setOptions(p => p.filter((_, idx) => idx !== i));
    if (quizAnswer >= i && quizAnswer > 0) setQuizAnswer(q => q - 1);
  };

  const updateOption = (i, val) => {
    setOptions(p => p.map((o, idx) => idx === i ? val : o));
  };

  const handleCreate = async () => {
    if (!question.trim()) { toast.error('Posez une question'); return; }
    const validOptions = options.filter(o => o.trim());
    if (validOptions.length < 2) { toast.error('Ajoutez au moins 2 options'); return; }
    setCreating(true);
    try {
      const pollOptions = validOptions.map((text, i) => ({ id: String(i), text: text.trim() }));
      const poll = await base44.entities.Poll.create({
        conversation_id: conversation.id,
        creator_email: user.email,
        creator_name: user.full_name || user.email.split('@')[0],
        question: question.trim(),
        options: pollOptions,
        votes: {},
        anonymous,
        multiple,
        is_quiz: isQuiz,
        quiz_answer_index: isQuiz ? quizAnswer : null,
        is_closed: false,
      });
      await base44.entities.Conversation.update(conversation.id, {
        last_message: `📊 ${question.trim()}`,
        last_message_at: new Date().toISOString(),
        last_message_sender: user.full_name || user.email.split('@')[0],
      });
      toast.success('Sondage créé !');
      onPollCreated(poll);
      handleClose();
    } catch {
      toast.error('Erreur lors de la création du sondage');
    } finally {
      setCreating(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-[300] flex items-end md:items-center justify-center">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={handleClose} />
          <motion.div
            initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
            className="relative w-full md:max-w-md glass-strong rounded-t-3xl md:rounded-2xl border border-white/10 z-10 max-h-[90vh] flex flex-col">

            {/* Header */}
            <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-white/8 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-orange-500/10 flex items-center justify-center">
                  <BarChart2 size={18} className="text-orange-400" />
                </div>
                <h2 className="text-base font-bold gradient-text">Nouveau sondage</h2>
              </div>
              <button onClick={handleClose} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground">
                <X size={18} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
              {/* Question */}
              <div className="glass rounded-2xl border border-white/10 p-4">
                <p className="text-xs font-semibold text-orange-400 mb-2">Question du sondage</p>
                <input
                  value={question}
                  onChange={e => setQuestion(e.target.value)}
                  placeholder="Posez une question..."
                  className="w-full bg-transparent text-sm outline-none text-foreground placeholder-muted-foreground"
                  maxLength={255}
                />
              </div>

              {/* Options */}
              <div className="glass rounded-2xl border border-white/10 p-4">
                <p className="text-xs font-semibold text-orange-400 mb-3">Options de réponse</p>
                <div className="space-y-2">
                  {options.map((opt, i) => (
                    <div key={i} className="flex items-center gap-2">
                      {isQuiz && (
                        <button onClick={() => setQuizAnswer(i)}
                          className={`w-4 h-4 rounded-full border-2 shrink-0 transition-all ${quizAnswer === i ? 'border-primary bg-primary' : 'border-white/30'}`} />
                      )}
                      <input
                        value={opt}
                        onChange={e => updateOption(i, e.target.value)}
                        placeholder={`Option ${i + 1}`}
                        className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary/50 text-foreground placeholder-muted-foreground"
                        maxLength={100}
                      />
                      {options.length > 2 && (
                        <button onClick={() => removeOption(i)} className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-all">
                          <X size={14} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                {options.length < 12 && (
                  <button onClick={addOption}
                    className="mt-3 flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors">
                    <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                      <Plus size={14} />
                    </div>
                    Ajouter une option...
                  </button>
                )}
                <p className="text-xs text-muted-foreground mt-2">
                  Vous pouvez encore ajouter {12 - options.length} option{12 - options.length !== 1 ? 's' : ''}.
                </p>
              </div>

              {/* Settings */}
              <div className="glass rounded-2xl border border-white/10 p-4">
                <p className="text-xs font-semibold text-orange-400 mb-3">Paramètres</p>
                <div className="space-y-3">
                  {[
                    { label: 'Vote anonyme', value: anonymous, set: setAnonymous },
                    { label: 'Réponses multiples', value: multiple, set: setMultiple },
                    { label: 'Mode quiz', value: isQuiz, set: setIsQuiz },
                  ].map(({ label, value, set }) => (
                    <div key={label} className="flex items-center justify-between">
                      <span className="text-sm text-foreground">{label}</span>
                      <button onClick={() => set(v => !v)}
                        className={`w-11 h-6 rounded-full transition-all relative ${value ? 'bg-primary' : 'bg-white/20'}`}>
                        <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${value ? 'left-5' : 'left-0.5'}`} />
                      </button>
                    </div>
                  ))}
                </div>
                {isQuiz && (
                  <p className="text-xs text-muted-foreground mt-2">
                    Les quiz n'ont qu'une seule bonne réponse. Sélectionnez-la ci-dessus.
                  </p>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="px-5 pb-5 pt-3 border-t border-white/8 shrink-0">
              <button onClick={handleCreate} disabled={creating}
                className="w-full py-3 rounded-xl bg-primary/15 border border-primary/30 hover:bg-primary/20 text-foreground font-semibold text-sm transition-all disabled:opacity-40 flex items-center justify-center gap-2">
                {creating ? <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /> : <><BarChart2 size={16} /> Créer le sondage</>}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}