import { useState, useRef } from 'react';
import { Mic, Square, Send, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function VoiceRecorder({ onSend, onCancel }) {
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [seconds, setSeconds] = useState(0);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mr = new MediaRecorder(stream);
    chunksRef.current = [];
    mr.ondataavailable = e => chunksRef.current.push(e.data);
    mr.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
      setAudioBlob(blob);
      setAudioUrl(URL.createObjectURL(blob));
      stream.getTracks().forEach(t => t.stop());
    };
    mr.start();
    mediaRecorderRef.current = mr;
    setRecording(true);
    setSeconds(0);
    timerRef.current = setInterval(() => setSeconds(s => s + 1), 1000);
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    clearInterval(timerRef.current);
    setRecording(false);
  };

  const handleSend = () => {
    if (!audioBlob) return;
    const file = new File([audioBlob], `voice_${Date.now()}.webm`, { type: 'audio/webm' });
    onSend(file);
  };

  const handleCancel = () => {
    clearInterval(timerRef.current);
    mediaRecorderRef.current?.stop();
    setRecording(false);
    setAudioBlob(null);
    setAudioUrl(null);
    onCancel();
  };

  const fmt = s => `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;

  return (
    <div className="flex items-center gap-2 flex-1">
      {!recording && !audioBlob && (
        <button onClick={startRecording}
          className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 transition-all">
          <Mic size={18} />
        </button>
      )}

      {recording && (
        <div className="flex items-center gap-2 flex-1">
          <div className="flex items-center gap-2 flex-1 bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2">
            <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ repeat: Infinity, duration: 1 }}
              className="w-2 h-2 rounded-full bg-red-500" />
            <span className="text-sm text-red-400 font-mono">{fmt(seconds)}</span>
          </div>
          <button onClick={stopRecording}
            className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-muted-foreground hover:bg-white/10 transition-all">
            <Square size={18} />
          </button>
          <button onClick={handleCancel}
            className="p-2.5 rounded-xl hover:bg-white/10 text-muted-foreground transition-all">
            <X size={18} />
          </button>
        </div>
      )}

      {audioBlob && !recording && (
        <div className="flex items-center gap-2 flex-1">
          <audio src={audioUrl} controls className="flex-1 h-9 rounded-xl" style={{ colorScheme: 'dark' }} />
          <button onClick={handleSend}
            className="p-2.5 rounded-xl bg-primary/20 border border-primary/30 text-primary hover:bg-primary/30 transition-all">
            <Send size={18} />
          </button>
          <button onClick={handleCancel}
            className="p-2.5 rounded-xl hover:bg-white/10 text-muted-foreground transition-all">
            <X size={18} />
          </button>
        </div>
      )}
    </div>
  );
}