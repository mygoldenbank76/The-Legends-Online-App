import { useState, useEffect } from 'react';
import { Link, useLocation, Outlet } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, MessageSquare, ShoppingBag, Settings, Menu, X, Zap, LogOut } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AnimatedBackground from './AnimatedBackground';
import ScrollToTop from './ScrollToTop';
import SessionTimeout from './SessionTimeout';

const navItems = [
  { path: '/Groups', icon: Users, label: 'Groupes' },
  { path: '/DirectMessages', icon: MessageSquare, label: 'Messages' },
  { path: '/Shop', icon: ShoppingBag, label: 'Shop' },
  { path: '/Settings', icon: Settings, label: 'Paramètres' },
];

export default function Layout() {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const openMenu = () => { setMobileOpen(true); document.body.style.overflow = 'hidden'; };
  const closeMenu = () => { setMobileOpen(false); document.body.style.overflow = ''; };

  const handleLogout = () => base44.auth.logout();

  return (
    <div className="h-screen bg-background relative overflow-hidden font-inter flex flex-col">
      <AnimatedBackground />
      <ScrollToTop />

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex fixed left-0 top-0 h-full w-64 flex-col glass-strong z-40 border-r border-white/5">
        {/* Logo */}
        <div className="px-6 py-6 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/20 flex items-center justify-center neon-purple">
              <Zap size={18} className="text-neon-purple" />
            </div>
            <span className="text-lg font-bold gradient-text">The Legends Online</span>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-4 py-6 space-y-1">
          {navItems.map(item => {
            const active = location.pathname === item.path;
            return (
              <Link key={item.path} to={item.path} className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative ${active ? 'bg-primary/15 text-primary neon-purple' : 'text-muted-foreground hover:text-foreground hover:bg-white/5'}`}>
                <item.icon size={18} className={active ? 'text-neon-purple' : 'group-hover:text-neon-purple transition-colors'} />
                <span className="text-sm font-medium">{item.label}</span>
                {active && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary animate-pulse-glow" />}
              </Link>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="px-4 py-4 border-t border-white/5">
          <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-3 w-full rounded-xl text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-all duration-200">
            <LogOut size={16} />
            <span className="text-sm font-medium">Déconnexion</span>
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="mobile-header md:hidden sticky top-0 z-40 glass-strong border-b border-white/5 shrink-0">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <Zap size={16} className="text-neon-purple" />
            </div>
            <span className="font-bold gradient-text text-sm">The Legends Online</span>
          </div>
          <button onClick={mobileOpen ? closeMenu : openMenu} className="p-2 rounded-lg hover:bg-white/10 transition-colors">
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </header>

      {/* Mobile Nav Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, x: -300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -300 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="md:hidden fixed inset-0 z-40"
          >
            <div className="absolute inset-0 bg-black/60" onClick={closeMenu} />
            <div className="absolute left-0 top-0 h-full w-72 glass-strong flex flex-col pt-20">
              <nav className="px-4 py-4 space-y-1">
                {navItems.map(item => {
                  const active = location.pathname === item.path;
                  return (
                    <Link key={item.path} to={item.path} onClick={closeMenu}
                      className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all relative ${active ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-white/5'}`}>
                      <item.icon size={18} />
                      <span className="text-sm font-medium">{item.label}</span>
                    </Link>
                  );
                })}
                <button onClick={() => { closeMenu(); handleLogout(); }} className="flex items-center gap-3 px-4 py-3 w-full rounded-xl text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-all">
                  <LogOut size={16} />
                  <span className="text-sm font-medium">Déconnexion</span>
                </button>
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main content */}
      <main className="md:ml-64 flex-1 pb-16 md:pb-0 relative z-10 flex flex-col overflow-hidden min-h-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="flex-1 overflow-hidden"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobile bottom nav */}
      <nav className="mobile-bottom-nav md:hidden fixed bottom-0 left-0 right-0 z-40 glass-strong border-t border-white/5 px-1 py-1.5 flex justify-around safe-area-bottom">
        {navItems.map(item => {
          const active = location.pathname === item.path;
          return (
            <Link key={item.path} to={item.path} className={`flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-xl transition-all min-w-0 relative ${active ? 'text-primary' : 'text-muted-foreground'}`}>
              <item.icon size={18} />
              <span className="text-[10px] font-medium truncate">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <SessionTimeout />
    </div>
  );
}