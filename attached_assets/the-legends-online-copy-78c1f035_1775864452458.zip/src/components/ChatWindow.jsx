import { useState, useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import UserProfileModal from './UserProfileModal';
import { useSendbirdChannel } from '@/hooks/useSendbirdChannel';
import CallScreen from './CallScreen';
import IncomingCallModal from './IncomingCallModal';
import { authenticateCalls } from '@/lib/sendbirdCalls';

import { base44 } from '@/api/base44Client';
import { Send, ArrowLeft, Paperclip, X, Reply, Pencil, Trash2, Mic, Phone, Video, MoreVertical, Bell, BellOff, Search, Camera, Images, FileText, BarChart2 } from 'lucide-react';
import PollCreatorModal from './PollCreatorModal';
import PollMessage from './PollMessage';
import ConversationInfoModal from './ConversationInfoModal';
import VoiceRecorder from './VoiceRecorder';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

const EMOJIS = ['❤️', '👍', '😂', '😮', '😢', '🔥', '🎉', '💯'];

function formatReplyContent(content, pollId) {
  if (content?.startsWith('[POLL:')) {
    return pollId ? `Sondage: Chargement...` : content;
  }
  return content;
}

function PollReplyLabel({ pollId }) {
  const [poll, setPoll] = useState(null);
  
  useEffect(() => {
    if (!pollId) return;
    base44.entities.Poll.filter({ id: pollId }).then(r => r[0] && setPoll(r[0]));
  }, [pollId]);
  
  return <span>Sondage: {poll?.question || 'Chargement...'}</span>;
}

function VideoMessage({ msg }) {
  const [loaded, setLoaded] = useState(false);
  const [isPortrait, setIsPortrait] = useState(true);
  const videoRef = useRef(null);

  const handleLoadedMetadata = () => {
    const v = videoRef.current;
    if (v) {
      setIsPortrait(v.videoHeight > v.videoWidth);
    }
    setLoaded(true);
  };

  return (
    <div
      className="relative overflow-hidden rounded-xl"
      style={{
        width: isPortrait ? '160px' : '280px',
        background: loaded ? 'transparent' : '#1a1a2e',
        minHeight: loaded ? undefined : (isPortrait ? '284px' : '157px'),
      }}
    >
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      )}
      <video
        ref={videoRef}
        src={msg.file_url}
        controls
        onLoadedMetadata={handleLoadedMetadata}
        className="rounded-xl w-full"
        style={{ display: loaded ? 'block' : 'none' }}
      />
      {loaded && (
        <span className="absolute bottom-2 right-2 flex items-center gap-1 text-[10px] text-white/80 bg-black/40 px-1.5 py-0.5 rounded-md whitespace-nowrap">
          {msg.is_edited && <span className="italic">modifié</span>}
          {format(new Date(msg.created_date), 'HH:mm')}
        </span>
      )}
    </div>
  );
}

function MessageActions({ msg, user, myUserId, onReply, onEdit, onDelete, onReact, onClose }) {
  const isMe = msg._sbSenderId === myUserId || msg.sender_email === user?.email;
  return (
    <div className="fixed inset-0 z-[500] flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div className="relative w-full max-w-sm mx-auto mb-4 px-4" onClick={e => e.stopPropagation()}>
        {/* Emoji row */}
        <div className="flex justify-around items-center glass-strong rounded-2xl border border-white/10 p-3 mb-2">
          {EMOJIS.map(emoji => (
            <button key={emoji} onClick={() => { onReact(msg, emoji); onClose(); }}
              className="text-2xl hover:scale-125 active:scale-110 transition-transform">
              {emoji}
            </button>
          ))}
        </div>
        {/* Actions list */}
        <div className="glass-strong rounded-2xl border border-white/10 overflow-hidden">
          <button onClick={() => { onReply(msg); onClose(); }}
            className="flex items-center gap-3 w-full px-4 py-3.5 hover:bg-white/8 transition-all text-left border-b border-white/5">
            <Reply size={18} className="text-muted-foreground" />
            <span className="text-sm font-medium">Répondre</span>
          </button>
          {isMe && !msg.content?.startsWith('[POLL:') && (
           <button onClick={() => { onEdit(msg); onClose(); }}
             className="flex items-center gap-3 w-full px-4 py-3.5 hover:bg-white/8 transition-all text-left border-b border-white/5">
             <Pencil size={18} className="text-muted-foreground" />
             <span className="text-sm font-medium">Modifier</span>
           </button>
          )}
          {isMe && (
            <button onClick={() => { onDelete(msg); onClose(); }}
              className="flex items-center gap-3 w-full px-4 py-3.5 hover:bg-red-500/10 transition-all text-left">
              <Trash2 size={18} className="text-red-400" />
              <span className="text-sm font-medium text-red-400">Supprimer</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function MessageItem({ msg, user, myUserId, onReply, onEdit, onDelete, onReact, onNameClick }) {
  const isMe = msg._sbSenderId === myUserId || msg.sender_email === user?.email;
  const [showActions, setShowActions] = useState(false);

  if (msg.is_deleted) {
    return (
      <div className={`flex ${isMe ? 'justify-end' : 'justify-start'} mb-1`}>
        <p className="text-xs text-muted-foreground italic px-3 py-1.5 rounded-xl bg-white/5 border border-white/5">Message supprimé</p>
      </div>
    );
  }

  const reactions = msg.reactions || {};

  return (
    <>
      {showActions && (
        <MessageActions
          msg={msg} user={user} myUserId={myUserId}
          onReply={onReply} onEdit={onEdit} onDelete={onDelete} onReact={onReact}
          onClose={() => setShowActions(false)}
        />
      )}
      <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} mb-3`}>
        {/* Sender name */}
        {!isMe && (
          <button
            onClick={() => onNameClick({ name: msg.sender_name, email: msg.sender_email })}
            className="text-xs text-muted-foreground mb-1 px-1 hover:text-primary transition-colors cursor-pointer"
          >
            {msg.sender_name || msg.sender_email?.split('@')[0]}
          </button>
        )}

        {/* Reply quote */}
        {msg.reply_to_id && (
          <div className={`mb-1 px-3 py-1.5 rounded-lg border-l-2 border-primary/50 bg-white/5 max-w-xs text-xs text-muted-foreground ${isMe ? 'text-right' : 'text-left'}`}>
            <p className="font-medium text-primary/70">{msg.reply_to_sender}</p>
            {msg.reply_to_content?.startsWith('[POLL:') ? (
              <PollReplyLabel pollId={msg.reply_to_content.match(/\[POLL:(.+?)\]/)?.[1]} />
            ) : (
              <p className="truncate">{msg.reply_to_content}</p>
            )}
          </div>
        )}

        {/* Bubble */}
        <div
          className={`relative max-w-xs md:max-w-md px-3 py-2 rounded-2xl cursor-pointer select-none ${isMe ? 'bg-primary/20 border border-primary/30 rounded-br-sm' : 'bg-white/15 border border-white/20 rounded-bl-sm'}`}
          onClick={() => !msg.content?.startsWith('[POLL:') && setShowActions(v => !v)}
          onContextMenu={(e) => { e.preventDefault(); setShowActions(v => !v); }}
        >
          {/* Poll */}
          {msg.content?.startsWith('[POLL:') && (() => {
            const pollId = msg.content.match(/\[POLL:(.+?)\]/)?.[1];
            return pollId ? (
              <div onClick={e => e.stopPropagation()}>
                <PollMessage pollId={pollId} user={user} createdDate={msg.created_date} reactions={reactions} />
              </div>
            ) : null;
          })()}

          {/* Image */}
          {msg.type === 'image' && msg.file_url && (
            <div className="relative">
              <img src={msg.file_url} alt="image" className="rounded-xl max-w-full max-h-60 object-cover" />
              {Object.values(reactions).every(u => !Array.isArray(u) || u.length === 0) && (
                <span className="absolute bottom-2 right-2 flex items-center gap-1 text-[10px] text-white/80 bg-black/40 px-1.5 py-0.5 rounded-md whitespace-nowrap">
                  {msg.is_edited && <span className="italic">modifié</span>}
                  {format(new Date(msg.created_date), 'HH:mm')}
                </span>
              )}
            </div>
          )}
          {/* Video */}
          {msg.type === 'video' && msg.file_url && (
            <VideoMessage msg={msg} />
          )}
          {/* Audio */}
          {msg.type === 'audio' && msg.file_url && (
            <div className="flex items-center gap-2">
              <audio src={msg.file_url} controls className="max-w-xs h-9 rounded-xl" style={{ colorScheme: 'dark' }} />
              <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                {format(new Date(msg.created_date), 'HH:mm')}
              </span>
            </div>
          )}
          {/* File */}
          {msg.type === 'file' && msg.file_url && (
            <div className="flex items-center justify-between gap-3">
              <a href={msg.file_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-neon-cyan hover:underline" onClick={e => e.stopPropagation()}>
                <Paperclip size={14} /> {msg.file_name || 'Fichier'}
              </a>
              <span className="flex items-center gap-1 text-[10px] text-muted-foreground whitespace-nowrap">
                {msg.is_edited && <span className="italic">modifié</span>}
                {format(new Date(msg.created_date), 'HH:mm')}
              </span>
            </div>
          )}

          {!msg.content?.startsWith('[POLL:') && (() => {
            const reactionEntries = Object.entries(reactions).filter(([, u]) => Array.isArray(u) && u.length > 0);
            const hasReactions = reactionEntries.length > 0;
            const isMedia = msg.type === 'image' || msg.type === 'file' || msg.type === 'video' || msg.type === 'audio';
            const timeSpan = (
              <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground whitespace-nowrap">
                {msg.is_edited && <span className="italic">modifié</span>}
                <span>{format(new Date(msg.created_date), 'HH:mm')}</span>
              </span>
            );

            const renderContent = () => {
              const parts = msg.content.split(/(@\w+)/g);
              return parts.map((part, i) => 
                part.startsWith('@') ? 
                  <span key={i} className="text-neon-cyan font-medium">{part}</span> : 
                  part
              );
            };

            if (!hasReactions) {
              if (isMedia) return null;
              return (
                <div className="relative">
                  <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">
                    {renderContent()}
                    <span className={`inline-block h-3 ${msg.is_edited ? 'w-24' : 'w-14'}`} />
                  </p>
                  <span className="absolute bottom-0 right-0">{timeSpan}</span>
                </div>
              );
            }

            const rows = [];
            for (let i = 0; i < reactionEntries.length; i += 5) rows.push(reactionEntries.slice(i, i + 5));
            return (
              <>
                {msg.type !== 'image' && msg.type !== 'file' && msg.type !== 'video' && (
                  <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap mb-1">{renderContent()}</p>
                )}
                {rows.map((row, rowIdx) => (
                  <div key={rowIdx} className="flex items-center gap-1 mt-1">
                    {row.map(([emoji, u]) => (
                      <button key={emoji} onClick={(e) => { e.stopPropagation(); onReact(msg, emoji); }}
                        className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/15 border border-white/20 text-xs hover:bg-white/25 transition-all">
                        {emoji} <span className="text-white/70">{u.length}</span>
                      </button>
                    ))}
                    {rowIdx === rows.length - 1 && (
                      <span className="ml-auto">{timeSpan}</span>
                    )}
                  </div>
                ))}
              </>
            );
          })()}
        </div>
      </div>
    </>
  );
}

export default function ChatWindow({ conversation, user, onBack, isDm, onReadConversation, allUsers = [] }) {
  const navigate = useNavigate();
  const {
    messages,
    myUserId,
    typingUsers,
    sendTextMessage,
    sendFileMessage,
    editMessage,
    deleteMessage,
    reactToMessage,
    startTyping,
    endTyping,
  } = useSendbirdChannel(conversation, user);

  useEffect(() => {
    onReadConversation?.(conversation?.id);
  }, [conversation?.id, onReadConversation]);

  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const [editMsg, setEditMsg] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [voiceMode, setVoiceMode] = useState(false);
  const [showMediaPicker, setShowMediaPicker] = useState(false);
  const [showPollModal, setShowPollModal] = useState(false);
  const mediaPickerRef = useRef(null);
  const [profileUser, setProfileUser] = useState(null);
  const [activeCall, setActiveCall] = useState(null);
  const [incomingCall, setIncomingCall] = useState(null);
  const [isVideoCall, setIsVideoCall] = useState(false);
  const sbCallsRef = useRef(null);

  // Init Sendbird Calls and listen for incoming calls
  useEffect(() => {
    if (!isDm || !user) return;
    let mounted = true;
    const initCalls = async () => {
      try {
        const authRes = await base44.functions.invoke('sendbirdAuth', {});
        const { userId, appId, accessToken } = authRes.data;
        const SBCall = await authenticateCalls(appId, userId, accessToken);
        sbCallsRef.current = SBCall;
        if (!mounted) return;
        SBCall.addListener('incoming_call', {
          onRinging: (call) => {
            if (mounted) setIncomingCall(call);
          }
        });
      } catch (e) {
        console.error('Calls init error:', e);
      }
    };
    initCalls();
    return () => { mounted = false; };
  }, [isDm, user]);

  const startCall = async (withVideo) => {
    if (!isDm || !conversation.member_emails) return;
    const otherEmail = conversation.member_emails.find(e => e !== user.email);
    if (!otherEmail) return;
    try {
      const res = await base44.functions.invoke('getCalleeInfo', { email: otherEmail });
      const calleeId = res.data.userId;
      const SBCall = sbCallsRef.current;
      if (!SBCall) { toast.error('Appels non disponibles'); return; }
      const call = SBCall.dial({
        userId: calleeId,
        isVideoCall: withVideo,
        callOption: { audioEnabled: true, videoEnabled: withVideo },
      });
      setIsVideoCall(withVideo);
      setActiveCall(call);
    } catch (e) {
      toast.error('Impossible de démarrer l\'appel');
    }
  };
  const menuRef = useRef(null);
  const [showInfo, setShowInfo] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [notifMuted, setNotifMuted] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [mentionSearch, setMentionSearch] = useState('');
  const [showMentions, setShowMentions] = useState(false);
  const bottomRef = useRef(null);
  const fileRef = useRef(null);
  const cameraRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setShowMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, []);

  const mentionableMembers = !isDm && conversation.member_emails 
    ? conversation.member_emails.filter(e => e !== user?.email)
    : [];

  const filteredMentions = mentionableMembers.filter(email => 
    email.toLowerCase().includes(mentionSearch.toLowerCase())
  );

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'auto' });
  }, [messages.length]);

  useEffect(() => {
    const container = document.querySelector('[data-messages-container]');
    if (!container) return;

    const handleMediaLoad = () => {
      bottomRef.current?.scrollIntoView({ behavior: 'auto' });
    };

    const images = container.querySelectorAll('img, video');
    images.forEach(media => {
      media.addEventListener('load', handleMediaLoad);
      media.addEventListener('loadedmetadata', handleMediaLoad);
    });

    return () => {
      images.forEach(media => {
        media.removeEventListener('load', handleMediaLoad);
        media.removeEventListener('loadedmetadata', handleMediaLoad);
      });
    };
  }, [messages]);

  const send = async (e) => {
    e?.preventDefault();
    const content = text.trim();
    if (!content && !editMsg) return;
    setSending(true);
    try {
      if (editMsg) {
        await editMessage(editMsg, content);
        setEditMsg(null);
      } else {
        await sendTextMessage(content, replyTo);
        await base44.entities.Conversation.update(conversation.id, {
          last_message: content,
          last_message_at: new Date().toISOString(),
          last_message_sender: user.full_name || user.email.split('@')[0],
        });
        setReplyTo(null);
      }
      setText('');
    } catch (err) {
      toast.error('Erreur lors de l\'envoi');
    } finally {
      setSending(false);
    }
  };

  const handleFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Sendbird limit: 25 MB
    const MAX_MB = 25;
    if (file.size > MAX_MB * 1024 * 1024) {
      toast.error(`Fichier trop lourd (max ${MAX_MB} Mo). Compressez la vidéo avant envoi.`);
      e.target.value = '';
      return;
    }

    setUploading(true);
    try {
      await sendFileMessage(file);
      const isImage = file.type.startsWith('image/');
      const isVideo = file.type.startsWith('video/');
      await base44.entities.Conversation.update(conversation.id, {
        last_message: isImage ? '📷 Image' : isVideo ? '🎥 Vidéo' : `📎 ${file.name}`,
        last_message_at: new Date().toISOString(),
        last_message_sender: user.full_name || user.email.split('@')[0],
      });
      toast.success('Fichier envoyé !');
    } catch (err) {
      console.error('Upload error:', err);
      toast.error('Erreur lors de l\'envoi du fichier. Vérifiez la taille (max 25 Mo).');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleReact = async (msg, emoji) => {
    await reactToMessage(msg, emoji);
  };

  const handleDelete = async (msg) => {
    await deleteMessage(msg);
  };

  const handleEdit = (msg) => {
    setEditMsg(msg);
    setText(msg.content);
    inputRef.current?.focus();
  };

  const handleMention = (email) => {
    const name = email === 'all' ? 'Tous' : email.split('@')[0];
    const beforeMention = text.substring(0, text.lastIndexOf('@'));
    setText(beforeMention + `@${name} `);
    setShowMentions(false);
    setMentionSearch('');
    inputRef.current?.focus();
  };

  const typingTimeoutRef = useRef(null);

  const handleTextChange = (value) => {
    setText(value);
    startTyping();
    clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => endTyping(), 3000);
    const lastAt = value.lastIndexOf('@');
    if (lastAt > -1) {
      const afterAt = value.substring(lastAt + 1);
      if (!afterAt.includes(' ')) {
        setMentionSearch(afterAt);
        setShowMentions(true);
      } else {
        setShowMentions(false);
      }
    } else {
      setShowMentions(false);
    }
  };

  const getDisplayName = () => {
    if (!isDm) return conversation.name;
    // Try to resolve from member_emails using allUsers
    if (conversation.member_emails?.length > 0) {
      const otherRaw = conversation.member_emails.find(e => e !== user?.email && e !== user?.id);
      if (otherRaw) {
        const byId = allUsers.find(u => u.id === otherRaw);
        if (byId) return byId.full_name || byId.email?.split('@')[0];
        const byEmail = allUsers.find(u => u.email === otherRaw);
        if (byEmail) return byEmail.full_name || byEmail.email?.split('@')[0];
        if (otherRaw.includes('@')) return otherRaw.split('@')[0];
      }
    }
    // If name contains '&', extract the other part
    if (conversation.name?.includes('&')) {
      const parts = conversation.name.split('&').map(p => p.trim());
      const currentPrefix = user?.email?.split('@')[0];
      const other = parts.find(p => p !== currentPrefix && p !== user?.full_name);
      if (other) return other;
    }
    return conversation.name;
  };

  const displayMessages = searchQuery.trim()
    ? messages.filter(m => m.content?.toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  const groupedMessages = displayMessages.reduce((acc, msg) => {
    const date = format(new Date(msg.created_date), 'dd MMMM yyyy', { locale: fr });
    if (!acc[date]) acc[date] = [];
    acc[date].push(msg);
    return acc;
  }, {});

  return (
    <div className="flex flex-col h-full">
      {/* Header - Fixed */}
      <div className="sticky top-0 z-40 flex items-center gap-3 px-4 py-3 border-b border-white/8 glass-strong shrink-0">
        <button onClick={onBack} className="md:hidden p-2 rounded-lg hover:bg-white/10 text-muted-foreground">
          <ArrowLeft size={18} />
        </button>
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center text-sm font-bold text-primary shrink-0">
          {conversation.avatar_url ? <img src={conversation.avatar_url} className="w-full h-full rounded-xl object-cover" alt="" /> : getDisplayName()?.charAt(0)?.toUpperCase()}
        </div>
        <button className="flex-1 min-w-0 text-left" onClick={() => setShowInfo(true)}>
          <p className="font-semibold text-sm truncate">{getDisplayName()}</p>
          {!isDm && conversation.member_emails && (
            <p className="text-xs text-muted-foreground">{conversation.member_emails?.length || 0} membres</p>
          )}
        </button>
        {isDm && (
          <div className="flex items-center gap-1">
            <button onClick={() => startCall(false)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-green-400 transition-all" title="Appel vocal">
              <Phone size={16} />
            </button>
            <button onClick={() => startCall(true)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-blue-400 transition-all" title="Appel vidéo">
              <Video size={16} />
            </button>
          </div>
        )}
        {!isDm && (
          <div className="relative" ref={menuRef}>
            <button onClick={() => setShowMenu(v => !v)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground transition-all">
              <MoreVertical size={16} />
            </button>
            {showMenu && (
              <div className="absolute right-0 top-full mt-1 z-50 rounded-xl border border-white/15 overflow-hidden min-w-[200px] shadow-2xl" style={{background: 'rgba(18, 20, 40, 0.97)', backdropFilter: 'blur(20px)'}}>
                <button
                  onClick={() => { setNotifMuted(v => !v); setShowMenu(false); }}
                  className="flex items-center gap-3 w-full px-4 py-3 hover:bg-white/8 transition-all text-left text-sm">
                  {notifMuted ? <Bell size={16} className="text-muted-foreground" /> : <BellOff size={16} className="text-muted-foreground" />}
                  {notifMuted ? 'Activer notifications' : 'Désactiver notifications'}
                </button>
                <button
                  onClick={() => { setShowSearch(v => !v); setShowMenu(false); }}
                  className="flex items-center gap-3 w-full px-4 py-3 hover:bg-white/8 transition-all text-left text-sm border-t border-white/5">
                  <Search size={16} className="text-muted-foreground" />
                  Rechercher
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Search bar */}
      <AnimatePresence>
        {showSearch && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="border-b border-white/8 bg-black/20 overflow-hidden">
            <div className="px-4 py-2 flex items-center gap-2">
              <Search size={14} className="text-muted-foreground shrink-0" />
              <input
                autoFocus
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Rechercher dans la conversation..."
                className="flex-1 bg-transparent text-sm outline-none text-foreground placeholder-muted-foreground"
              />
              <button onClick={() => { setShowSearch(false); setSearchQuery(''); }} className="p-1 rounded hover:bg-white/10">
                <X size={14} className="text-muted-foreground" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4" style={{scrollbarWidth: 'none', msOverflowStyle: 'none'}} data-messages-container>
        {Object.entries(groupedMessages).map(([date, msgs]) => (
          <div key={date}>
            <div className="flex items-center gap-3 my-4">
              <div className="flex-1 h-px bg-white/8" />
              <p className="text-[10px] text-muted-foreground px-2">{date}</p>
              <div className="flex-1 h-px bg-white/8" />
            </div>
            {msgs.map(msg => (
              <MessageItem key={msg.id} msg={msg} user={user} myUserId={myUserId} onReply={setReplyTo} onEdit={handleEdit} onDelete={handleDelete} onReact={handleReact} onNameClick={setProfileUser} />
            ))}
          </div>
        ))}
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full gap-3 text-center">
            <p className="text-sm text-muted-foreground">Aucun message pour l'instant</p>
            <p className="text-xs text-muted-foreground">Soyez le premier à écrire !</p>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Typing indicator */}
      {typingUsers.length > 0 && (
        <div className="px-4 py-1.5 text-xs text-muted-foreground italic">
          {typingUsers.join(', ')} {typingUsers.length === 1 ? 'est en train d\'écrire' : 'sont en train d\'écrire'}...
        </div>
      )}

      {/* Call screens */}
      <AnimatePresence>
        {activeCall && (
          <CallScreen
            call={activeCall}
            isVideo={isVideoCall}
            calleeName={getDisplayName()}
            onEnd={() => setActiveCall(null)}
          />
        )}
        {incomingCall && !activeCall && (
          <IncomingCallModal
            call={incomingCall}
            onAccept={() => { setIsVideoCall(incomingCall.isVideoCall); setActiveCall(incomingCall); setIncomingCall(null); }}
            onDecline={() => { incomingCall.end(); setIncomingCall(null); }}
          />
        )}
      </AnimatePresence>

      <PollCreatorModal
        isOpen={showPollModal}
        onClose={() => setShowPollModal(false)}
        conversation={conversation}
        user={user}
        onPollCreated={async (poll) => {
          await sendTextMessage(`[POLL:${poll.id}]`, null);
        }}
      />

      {showInfo && (
        <ConversationInfoModal
          conversation={conversation}
          messages={messages}
          user={user}
          isDm={isDm}
          onClose={() => setShowInfo(false)}
        />
      )}

      <AnimatePresence>
        {profileUser && (
          <UserProfileModal targetUser={profileUser} currentUser={user} onClose={() => setProfileUser(null)} onDmCreated={!isDm ? (conv) => { localStorage.setItem('dm_open_conv_id', conv.id); navigate('/DirectMessages'); setProfileUser(null); } : null} />
        )}
      </AnimatePresence>

      {/* Reply bar */}
      <AnimatePresence>
       {replyTo && (
         <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
           className="px-4 py-2 border-t border-white/8 bg-black/20 flex items-center gap-2">
           <Reply size={14} className="text-primary shrink-0" />
           <div className="flex-1 min-w-0">
             <p className="text-xs font-medium text-primary">{replyTo.sender_name}</p>
             {replyTo.content?.startsWith('[POLL:') ? (
               <PollReplyLabel pollId={replyTo.content.match(/\[POLL:(.+?)\]/)?.[1]} />
             ) : (
               <p className="text-xs text-muted-foreground truncate">{replyTo.content}</p>
             )}
           </div>
            <button onClick={() => setReplyTo(null)} className="p-1 rounded hover:bg-white/10">
              <X size={14} className="text-muted-foreground" />
            </button>
          </motion.div>
        )}
        {editMsg && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="px-4 py-2 border-t border-white/8 bg-yellow-500/5 flex items-center gap-2">
            <Pencil size={14} className="text-yellow-400 shrink-0" />
            <p className="text-xs text-yellow-300 flex-1">Mode édition</p>
            <button onClick={() => { setEditMsg(null); setText(''); }} className="p-1 rounded hover:bg-white/10">
              <X size={14} className="text-muted-foreground" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Media Picker overlay + Panel */}
      {showMediaPicker && (
        <div className="fixed inset-0 z-10" onClick={() => setShowMediaPicker(false)} />
      )}
      <AnimatePresence>
        {showMediaPicker && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="border-t border-white/8 glass-strong overflow-hidden relative z-20"
          >
            <div className="grid grid-cols-4 gap-3 p-4">
              {[
                { label: 'Caméra', Icon: Camera, color: 'bg-pink-500/20 border-pink-500/30 text-pink-400', isCamera: true },
                { label: 'Galerie', Icon: Images, color: 'bg-blue-500/20 border-blue-500/30 text-blue-400', action: () => { fileRef.current.accept = 'image/*,video/*'; fileRef.current?.click(); setShowMediaPicker(false); } },
                { label: 'Documents', Icon: FileText, color: 'bg-purple-500/20 border-purple-500/30 text-purple-400', action: () => { fileRef.current.accept = 'application/pdf,.doc,.docx,.txt'; fileRef.current?.click(); setShowMediaPicker(false); } },
                { label: 'Sondage', Icon: BarChart2, color: 'bg-orange-500/20 border-orange-500/30 text-orange-400', action: () => { setShowMediaPicker(false); setShowPollModal(true); } },
              ].map(({ label, Icon, color, action, isCamera }) => (
                isCamera ? (
                  <label key={label} htmlFor="camera-capture" onClick={() => setShowMediaPicker(false)}
                    className={`flex flex-col items-center gap-2 py-3 rounded-2xl border ${color} hover:brightness-110 transition-all cursor-pointer`}>
                    <Icon size={24} />
                    <span className="text-xs font-medium text-foreground/80">{label}</span>
                  </label>
                ) : (
                  <button key={label} onClick={action}
                    className={`flex flex-col items-center gap-2 py-3 rounded-2xl border ${color} hover:brightness-110 transition-all`}>
                    <Icon size={24} />
                    <span className="text-xs font-medium text-foreground/80">{label}</span>
                  </button>
                )
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input */}
      <div className="px-4 py-3 border-t border-white/8 glass-strong shrink-0">
        <form onSubmit={send} className="flex items-center gap-2">
          <input ref={fileRef} type="file" className="hidden" onChange={handleFile} accept="image/*,video/*,application/pdf,.doc,.docx,.txt" />
          <input id="camera-capture" type="file" className="hidden" onChange={(e) => { handleFile(e); setShowMediaPicker(false); }} accept="image/*" capture="environment" />

          {voiceMode ? (
            <VoiceRecorder
              onSend={async (file) => {
                setVoiceMode(false);
                setUploading(true);
                try {
                  await sendFileMessage(file);
                  await base44.entities.Conversation.update(conversation.id, {
                    last_message: '🎤 Message vocal',
                    last_message_at: new Date().toISOString(),
                    last_message_sender: user.full_name || user.email.split('@')[0],
                  });
                } finally { setUploading(false); }
              }}
              onCancel={() => setVoiceMode(false)}
            />
          ) : (
          <>
          <button type="button" onClick={() => setShowMediaPicker(v => !v)}
            className="p-2.5 rounded-xl bg-primary/20 border border-primary/30 hover:bg-primary/30 text-primary transition-colors shrink-0 relative z-30" disabled={uploading}>
            {uploading ? <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /> : <Paperclip size={18} />}
          </button>
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              value={text}
              onChange={e => handleTextChange(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send(e)}
              placeholder={editMsg ? 'Modifier le message...' : 'Écrire un message...'}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-primary/50 placeholder-muted-foreground text-foreground transition-all"
            />
            {showMentions && !isDm && (
              <div className="absolute bottom-full left-0 right-0 mb-2 glass-strong rounded-xl border border-white/10 max-h-48 overflow-y-auto z-10">
                {filteredMentions.length > 0 && (
                  <>
                    <button
                      onClick={() => handleMention('all')}
                      className="w-full text-left px-4 py-2.5 hover:bg-white/10 transition-all text-sm font-medium text-neon-cyan border-b border-white/5"
                    >
                      @Tous
                    </button>
                    {filteredMentions.map(email => (
                      <button
                        key={email}
                        onClick={() => handleMention(email)}
                        className="w-full text-left px-4 py-2.5 hover:bg-white/10 transition-all text-sm border-b border-white/5 last:border-0"
                      >
                        @{email.split('@')[0]}
                      </button>
                    ))}
                  </>
                )}
              </div>
            )}
          </div>
          <AnimatePresence mode="wait">
            {text.trim() || editMsg ? (
              <motion.button
                key="send"
                type="submit"
                disabled={sending}
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.5, opacity: 0 }}
                transition={{ duration: 0.15 }}
                className="p-2.5 rounded-xl bg-primary/20 border border-primary/30 hover:bg-primary/30 text-primary transition-colors shrink-0">
                <Send size={18} />
              </motion.button>
            ) : (
              <motion.button
                key="mic"
                type="button"
                onClick={() => setVoiceMode(true)}
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.5, opacity: 0 }}
                transition={{ duration: 0.15 }}
                className="p-2.5 rounded-xl bg-primary/20 border border-primary/30 hover:bg-primary/30 text-primary transition-colors shrink-0">
                <Mic size={18} />
              </motion.button>
            )}
          </AnimatePresence>
          </>
          )}
        </form>
      </div>
    </div>
  );
}