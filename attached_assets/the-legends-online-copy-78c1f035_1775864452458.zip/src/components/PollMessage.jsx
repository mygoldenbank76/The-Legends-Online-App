import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { BarChart2, Lock } from 'lucide-react';
import { format } from 'date-fns';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

export default function PollMessage({ pollId, user, createdDate, reactions = {} }) {
  const [poll, setPoll] = useState(null);
  const [voting, setVoting] = useState(false);
  const [showVotersModal, setShowVotersModal] = useState(false);

  useEffect(() => {
    base44.entities.Poll.filter({ id: pollId }).then(r => r[0] && setPoll(r[0]));
    const unsub = base44.entities.Poll.subscribe(e => {
      if (e.id === pollId) setPoll(e.data);
    });
    return unsub;
  }, [pollId]);

  if (!poll) return (
    <div className="w-56 py-4 flex items-center justify-center">
      <div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  const votes = poll.votes || {};
  const totalVotes = Object.values(votes).reduce((sum, arr) => sum + (Array.isArray(arr) ? arr.length : 0), 0);
  const userVotes = Object.entries(votes).filter(([, arr]) => Array.isArray(arr) && arr.includes(user.email)).map(([id]) => id);
  const hasVoted = userVotes.length > 0;

  const handleVote = async (optionId) => {
    if (poll.is_closed || voting) return;
    setVoting(true);
    try {
      const currentVotes = { ...votes };
      if (!poll.multiple) {
        // Remove previous vote
        for (const k in currentVotes) {
          currentVotes[k] = (currentVotes[k] || []).filter(e => e !== user.email);
        }
      }
      const already = (currentVotes[optionId] || []).includes(user.email);
      if (already) {
        currentVotes[optionId] = (currentVotes[optionId] || []).filter(e => e !== user.email);
      } else {
        currentVotes[optionId] = [...(currentVotes[optionId] || []), user.email];
      }
      const updated = await base44.entities.Poll.update(poll.id, { votes: currentVotes });
      setPoll(updated);
    } finally {
      setVoting(false);
    }
  };

  const getPercent = (optionId) => {
    if (totalVotes === 0) return 0;
    return Math.round(((votes[optionId] || []).length / totalVotes) * 100);
  };

  const showResults = hasVoted || poll.is_closed;

  return (
    <div className="w-64 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-start gap-2 mb-3">
        <BarChart2 size={16} className="text-primary shrink-0 mt-0.5" />
        <p className="text-sm font-semibold text-foreground leading-tight">{poll.question}</p>
      </div>

      {/* Options */}
      <div className="space-y-2">
        {poll.options.map((opt) => {
          const pct = getPercent(opt.id);
          const isVoted = userVotes.includes(opt.id);
          const isCorrect = poll.is_quiz && poll.quiz_answer_index === Number(opt.id);
          const count = (votes[opt.id] || []).length;

          return (
            <button key={opt.id} onClick={(e) => { e.stopPropagation(); handleVote(opt.id); }} disabled={poll.is_closed || voting}
              className={`w-full text-left rounded-xl overflow-hidden border transition-all ${isVoted ? 'border-primary/60' : 'border-white/15'} ${poll.is_closed ? 'cursor-default' : 'hover:border-primary/40'}`}>
              <div className="relative px-3 py-2.5">
                {/* Progress bar */}
                {showResults && (
                  <div className={`absolute inset-0 transition-all duration-500 ${isCorrect ? 'bg-green-500/20' : isVoted ? 'bg-primary/15' : 'bg-white/5'}`}
                    style={{ width: `${pct}%`, maxWidth: '100%' }} />
                )}
                <div className="relative flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {isVoted && (
                      <div className="w-3.5 h-3.5 rounded-full bg-primary flex items-center justify-center shrink-0">
                        <div className="w-1.5 h-1.5 rounded-full bg-white" />
                      </div>
                    )}
                    <span className={`text-xs font-medium ${isCorrect ? 'text-green-400' : isVoted ? 'text-primary' : 'text-foreground/90'}`}>
                      {opt.text}
                    </span>
                  </div>
                  {showResults && (
                    <span className="text-[10px] text-muted-foreground shrink-0 font-medium">{pct}%</span>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Show votes button */}
      {!poll.anonymous && totalVotes > 0 && (
        <button
          onClick={() => setShowVotersModal(true)}
          className="w-full text-center py-2 mt-2 text-sm font-medium text-primary hover:bg-primary/10 bg-primary/5 rounded-lg transition-all border border-primary/30"
        >
          Voir les votes
        </button>
      )}

      {/* Voters modal */}
      <Dialog open={showVotersModal} onOpenChange={setShowVotersModal}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Votes</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 max-h-60 overflow-y-auto">
            {poll.options.map(opt => {
              const voters = votes[opt.id] || [];
              if (voters.length === 0) return null;
              return (
                <div key={opt.id}>
                  <p className="text-xs font-semibold text-foreground mb-2">{opt.text}</p>
                  <div className="flex flex-wrap gap-2">
                    {voters.map(email => (
                      <span key={email} className="px-3 py-1 rounded-full bg-primary/20 border border-primary/30 text-xs text-foreground">
                        {email.split('@')[0]}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {/* Footer with reactions and vote count */}
      <div className="flex items-center justify-between mt-2 pt-2 pb-1 border-t border-white/8 gap-1 flex-nowrap overflow-x-auto">
        <div className="flex items-center gap-1 flex-wrap">
          {Object.entries(reactions).filter(([, u]) => Array.isArray(u) && u.length > 0).map(([emoji, u]) => (
            <button key={emoji} className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/15 border border-white/20 text-xs">
              {emoji} <span className="text-white/70">{u.length}</span>
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 ml-auto">
          <span className="text-[10px] text-muted-foreground">
            {totalVotes} vote{totalVotes !== 1 ? 's' : ''}
            {poll.anonymous ? ' · Anonyme' : ''}
            {poll.is_quiz ? ' · Quiz' : ''}
          </span>
          <span className="text-[10px] text-muted-foreground">·</span>
          <div className="flex items-center gap-1">
            {poll.is_closed && <Lock size={10} className="text-muted-foreground" />}
            <span className="text-[10px] text-muted-foreground">{format(new Date(createdDate), 'HH:mm')}</span>
          </div>
        </div>
      </div>
    </div>
  );
}