import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Users, Image, FileText, Mic, Link2, Copy, Check } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { toast } from 'sonner';

const TABS = ['Médias', 'Fichiers', 'Voix'];

export default function ConversationInfoModal({ conversation, messages, user, isDm, onClose }) {
  const [tab, setTab] = useState('Médias');
  const [copied, setCopied] = useState(false);
  const [viewMedia, setViewMedia] = useState(null);

  const displayName = useMemo(() => {
    if (!isDm || !user || !conversation.member_emails) return conversation.name;
    const other = conversation.member_emails.find(e => e !== user.email);
    return other ? other.split('@')[0] : conversation.name;
  }, [isDm, user, conversation]);

  const otherEmail = isDm && conversation.member_emails?.find(e => e !== user?.email);

  const mediaMessages = useMemo(() => messages.filter(m => m.type === 'image' || m.type === 'video'), [messages]);
  const fileMessages = useMemo(() => messages.filter(m => m.type === 'file'), [messages]);
  const voiceMessages = useMemo(() => messages.filter(m => m.type === 'audio'), [messages]);

  const groupLink = `legends://group/${conversation.id}`;

  const copyLink = () => {
    navigator.clipboard.writeText(groupLink);
    setCopied(true);
    toast.success('Lien copié !');
    setTimeout(() => setCopied(false), 2000);
  };

  const tabContent = () => {
    if (tab === 'Médias') {
      if (mediaMessages.length === 0) return <Empty text="Aucun média partagé" />;
      return (
        <div className="grid grid-cols-3 gap-0.5">
          {mediaMessages.map(m => (
            <div key={m.id} className="aspect-square overflow-hidden bg-white/5 cursor-pointer" onClick={() => setViewMedia(m)}>
              {m.type === 'image' ? (
                <img src={m.file_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <video src={m.file_url} className="w-full h-full object-cover" />
              )}
            </div>
          ))}
        </div>
      );
    }
    if (tab === 'Fichiers') {
      if (fileMessages.length === 0) return <Empty text="Aucun fichier partagé" />;
      return (
        <div className="px-4 space-y-2">
          {fileMessages.map(m => (
            <a key={m.id} href={m.file_url} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/8 hover:bg-white/10 transition-all">
              <div className="w-9 h-9 rounded-lg bg-cyan-500/10 flex items-center justify-center shrink-0">
                <FileText size={16} className="text-neon-cyan" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{m.file_name || 'Fichier'}</p>
                <p className="text-xs text-muted-foreground">{format(new Date(m.created_date), 'dd MMM yyyy', { locale: fr })}</p>
              </div>
            </a>
          ))}
        </div>
      );
    }
    if (tab === 'Voix') {
      if (voiceMessages.length === 0) return <Empty text="Aucun message vocal" />;
      return (
        <div className="px-4 space-y-2">
          {voiceMessages.map(m => (
            <div key={m.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/8">
              <div className="w-9 h-9 rounded-lg bg-purple-500/10 flex items-center justify-center shrink-0">
                <Mic size={16} className="text-neon-purple" />
              </div>
              <div className="flex-1 min-w-0">
                <audio src={m.file_url} controls className="w-full h-8" style={{ colorScheme: 'dark' }} />
              </div>
              <p className="text-xs text-muted-foreground shrink-0">{format(new Date(m.created_date), 'HH:mm')}</p>
            </div>
          ))}
        </div>
      );
    }
  };

  return (
    <>
    {viewMedia && (
      <div className="fixed inset-0 z-[700] flex items-center justify-center bg-black/90" onClick={() => setViewMedia(null)}>
        <button className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 z-10" onClick={() => setViewMedia(null)}>
          <X size={20} />
        </button>
        {viewMedia.type === 'image' ? (
          <img src={viewMedia.file_url} alt="" className="max-w-full max-h-full object-contain rounded-xl" onClick={e => e.stopPropagation()} />
        ) : (
          <video src={viewMedia.file_url} controls autoPlay className="max-w-full max-h-full rounded-xl" onClick={e => e.stopPropagation()} />
        )}
      </div>
    )}
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[600] flex items-end md:items-center justify-center"
        onClick={onClose}
      >
        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 60 }}
          onClick={e => e.stopPropagation()}
          className="relative w-full md:max-w-md glass-strong rounded-t-3xl md:rounded-2xl border border-white/10 z-10 max-h-[90vh] flex flex-col overflow-hidden"
        >
          {/* Close */}
          <button onClick={onClose} className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-all">
            <X size={16} />
          </button>

          {/* Header */}
          <div className="flex flex-col items-center pt-8 pb-5 px-6 text-center shrink-0">
            <div className="w-20 h-20 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center text-3xl font-bold text-primary mb-3 overflow-hidden">
              {conversation.avatar_url
                ? <img src={conversation.avatar_url} className="w-full h-full object-cover" alt="" />
                : displayName?.charAt(0)?.toUpperCase()
              }
            </div>
            <h2 className="text-xl font-bold text-foreground">{displayName}</h2>
            {isDm
              ? <p className="text-sm text-muted-foreground mt-0.5">{otherEmail}</p>
              : <p className="text-sm text-muted-foreground mt-0.5">{conversation.member_emails?.length || 0} membres</p>
            }
            {conversation.description && (
              <p className="text-xs text-muted-foreground mt-2 max-w-xs">{conversation.description}</p>
            )}
          </div>

          {/* Group link (groups only) */}
          {!isDm && (
            <div className="mx-4 mb-4 shrink-0">
              <button onClick={copyLink}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-left">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center shrink-0">
                  {copied ? <Check size={15} className="text-green-400" /> : <Link2 size={15} className="text-neon-cyan" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground">Lien du groupe</p>
                  <p className="text-sm text-foreground truncate">{groupLink}</p>
                </div>
                <Copy size={14} className="text-muted-foreground shrink-0" />
              </button>
            </div>
          )}


          {/* Tabs */}
          <div className="flex border-b border-white/8 shrink-0 mx-4">
            {TABS.map(t => (
              <button key={t} onClick={() => setTab(t)}
                className={`flex-1 py-2.5 text-xs font-medium transition-all border-b-2 ${tab === t ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
                {t}
              </button>
            ))}
          </div>

          {/* Tab content */}
          <div className="flex-1 overflow-y-auto py-3">
            {tabContent()}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
    </>
  );
}

function Empty({ text }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 gap-2">
      <p className="text-sm text-muted-foreground">{text}</p>
    </div>
  );
}