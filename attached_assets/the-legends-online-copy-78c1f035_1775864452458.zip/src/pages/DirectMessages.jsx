import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { MessageSquare, Plus } from 'lucide-react';
import { useNotifications } from '@/hooks/useNotifications';
import ConversationList from '../components/ConversationList';
import ChatWindow from '../components/ChatWindow';
import NewConversationModal from '../components/NewConversationModal';

const dmCache = { data: null };
const usersCache = { data: null };

export default function DirectMessages() {
  const [conversations, setConversations] = useState(() => dmCache.data || []);
  const [selected, setSelected] = useState(null);
  const [user, setUser] = useState(() => {
    try { const c = localStorage.getItem('app_user_cache'); return c ? JSON.parse(c) : null; } catch { return null; }
  });
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [allUsers, setAllUsers] = useState(() => usersCache.data || []);
  const { markConversationAsRead } = useNotifications(user);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      try { localStorage.setItem('app_user_cache', JSON.stringify(u)); } catch {}
    });
    base44.entities.User.list().then(users => {
      usersCache.data = users;
      setAllUsers(users);
    });
    const init = async () => {
      const convs = await loadConversations();
      const openId = localStorage.getItem('dm_open_conv_id');
      if (openId) {
        localStorage.removeItem('dm_open_conv_id');
        const target = convs?.find(c => c.id === openId);
        if (target) { setSelected(target); setShowChat(true); }
      }
    };
    init();
    const unsub = base44.entities.Conversation.subscribe((e) => {
      if (e.type === 'create' && e.data.type === 'direct') setConversations(p => [e.data, ...p]);
      if (e.type === 'update') setConversations(p => p.map(c => c.id === e.id ? e.data : c));
      if (e.type === 'delete') setConversations(p => p.filter(c => c.id !== e.id));
    });
    return unsub;
  }, []);

  const loadConversations = async () => {
    const all = await base44.entities.Conversation.filter({ type: 'direct' }, '-last_message_at', 50);
    dmCache.data = all;
    setConversations(all);
    return all;
  };

  const handleSelect = (conv) => {
    setSelected(conv);
    setShowChat(true);
  };

  const handleBack = () => {
    setShowChat(false);
    setSelected(null);
  };

  useEffect(() => {
    if (showChat) document.body.classList.add('chat-open');
    else document.body.classList.remove('chat-open');
    return () => document.body.classList.remove('chat-open');
  }, [showChat]);

  const getDmName = (conv) => {
    if (!user || !conv.member_emails) return conv.name;
    const other = conv.member_emails.find(e => e !== user.email);
    return other?.split('@')[0] || conv.name;
  };

  const filtered = conversations.filter(c =>
    getDmName(c)?.toLowerCase().includes(search.toLowerCase())
  );

  const handleProfileDm = (conv) => {
    if (!conversations.find(c => c.id === conv.id)) {
      setConversations(p => [conv, ...p]);
    }
    setSelected(conv);
    setShowChat(true);
  };

  return (
    <div className="flex h-full overflow-hidden min-h-0">
      {/* Sidebar */}
      <div className={`${showChat ? 'hidden md:flex' : 'flex'} relative flex-col w-full md:w-80 lg:w-96 border-r border-white/8 bg-black/20 h-full min-h-0 overflow-hidden`}>
        {conversations.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-3 text-center p-6">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 flex items-center justify-center">
              <MessageSquare size={24} className="text-neon-cyan" />
            </div>
            <p className="text-sm text-muted-foreground">Aucun message privé</p>
          </div>
        ) : (
          <ConversationList conversations={conversations} selected={selected} onSelect={handleSelect} user={user} isDm allUsers={allUsers} />
        )}
        {/* FAB */}
        {!showChat && !showModal && (
          <button
            onClick={() => setShowModal(true)}
            className="fixed bottom-20 right-4 w-10 h-10 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center shadow-lg hover:bg-primary/30 transition-all z-[150] neon-purple">
            <Plus size={22} className="text-neon-purple" />
          </button>
        )}
      </div>

      {/* Chat */}
      <div className={`${showChat ? 'fixed inset-0 z-[200] flex md:relative md:inset-auto md:z-auto' : 'hidden md:flex'} flex-1 flex-col min-h-0 min-w-0`} style={showChat ? {background: 'hsl(230, 25%, 5%)'} : {}}>
        {selected ? (
          <ChatWindow conversation={selected} user={user} onBack={handleBack} isDm onReadConversation={markConversationAsRead} allUsers={allUsers} />
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex flex-col items-center justify-center gap-4 text-center p-8">
            <div className="w-20 h-20 rounded-3xl bg-cyan-500/10 flex items-center justify-center neon-cyan">
              <MessageSquare size={32} className="text-neon-cyan" />
            </div>
            <h2 className="text-xl font-bold gradient-text">Vos messages</h2>
            <p className="text-sm text-muted-foreground max-w-xs">Envoyez des messages privés à d'autres membres de l'application.</p>
            <button onClick={() => setShowModal(true)} className="px-4 py-2 rounded-xl bg-primary/10 border border-primary/30 text-sm font-medium text-foreground hover:bg-primary/20 transition-all flex items-center gap-2">
              <Plus size={16} /> Nouveau message
            </button>
          </motion.div>
        )}
      </div>

      <NewConversationModal isOpen={showModal} onClose={() => setShowModal(false)} type="direct" user={user} onCreate={(conv) => { setConversations(p => [conv, ...p]); setSelected(conv); setShowChat(true); }} onProfileDm={(conv) => { setConversations(p => p.find(c => c.id === conv.id) ? p : [conv, ...p]); setSelected(conv); setShowChat(true); }} />
    </div>
  );
}