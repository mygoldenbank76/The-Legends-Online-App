import { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, ExternalLink, RefreshCw } from 'lucide-react';

export default function Shop() {
  const [loading, setLoading] = useState(true);
  const [key, setKey] = useState(0);

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/8 glass-strong shrink-0 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-pink-500/10 flex items-center justify-center">
            <ShoppingBag size={16} className="text-neon-pink" />
          </div>
          <div>
            <h1 className="text-sm font-bold gradient-text-pink">The Legends Shop</h1>
            <p className="text-xs text-muted-foreground">goldenvibeofficiel.com</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => { setKey(k => k + 1); setLoading(true); }} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-foreground transition-all">
            <RefreshCw size={16} />
          </button>
          <a href="https://www.goldenvibeofficiel.com/" target="_blank" rel="noopener noreferrer" className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-foreground transition-all">
            <ExternalLink size={16} />
          </a>
        </div>
      </div>

      {/* Iframe */}
      <div className="flex-1 relative overflow-hidden">
        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 flex flex-col items-center justify-center gap-4 z-10 bg-background">
            <div className="w-16 h-16 rounded-3xl bg-pink-500/10 flex items-center justify-center">
              <ShoppingBag size={28} className="text-neon-pink" />
            </div>
            <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            <p className="text-sm text-muted-foreground">Chargement de la boutique...</p>
          </motion.div>
        )}
        <iframe
          key={key}
          src="https://www.goldenvibeofficiel.com/"
          className="w-full h-full border-0"
          onLoad={() => setLoading(false)}
          onError={() => setLoading(false)}
          title="The Legends Shop"
          allow="payment; fullscreen"
          sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-top-navigation"
          referrerPolicy="no-referrer"
          style={{ minHeight: '100%' }}
        />
      </div>
    </div>
  );
}