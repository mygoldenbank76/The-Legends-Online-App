import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useNotifications } from '@/hooks/useNotifications';
import { Users, Plus, Search } from 'lucide-react';
import ConversationList from '../components/ConversationList';
import ChatWindow from '../components/ChatWindow';
import NewConversationModal from '../components/NewConversationModal';

const groupsCache = { data: null };

export default function Groups() {
  const [conversations, setConversations] = useState(() => groupsCache.data || []);
  const [selected, setSelected] = useState(null);
  const [user, setUser] = useState(() => {
    try { const c = localStorage.getItem('app_user_cache'); return c ? JSON.parse(c) : null; } catch { return null; }
  });
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [joinTarget, setJoinTarget] = useState(null);
  const [joining, setJoining] = useState(false);
  const { markConversationAsRead } = useNotifications(user);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      try { localStorage.setItem('app_user_cache', JSON.stringify(u)); } catch {}
    });
    loadConversations();
    const unsub = base44.entities.Conversation.subscribe((e) => {
      if (e.type === 'create') setConversations(p => [e.data, ...p]);
      if (e.type === 'update') setConversations(p => p.map(c => c.id === e.id ? e.data : c));
      if (e.type === 'delete') setConversations(p => p.filter(c => c.id !== e.id));
    });
    return unsub;
  }, []);

  const loadConversations = async () => {
    const all = await base44.entities.Conversation.filter({ type: 'group' }, '-last_message_at', 50);
    groupsCache.data = all;
    setConversations(all);
  };

  const handleSelect = (conv) => {
    if (!user) return;
    const isMember = conv.member_emails?.includes(user.email);
    if (!isMember) {
      setJoinTarget(conv);
    } else {
      setSelected(conv);
      setShowChat(true);
    }
  };

  const handleJoin = async () => {
    if (!joinTarget || !user) return;
    setJoining(true);
    const updatedEmails = [...(joinTarget.member_emails || []), user.email];
    const updatedIds = [...(joinTarget.member_ids || []), user.id];
    const updated = await base44.entities.Conversation.update(joinTarget.id, {
      member_emails: updatedEmails,
      member_ids: updatedIds,
    });
    setConversations(p => p.map(c => c.id === joinTarget.id ? { ...c, member_emails: updatedEmails, member_ids: updatedIds } : c));
    setJoining(false);
    setSelected({ ...joinTarget, member_emails: updatedEmails, member_ids: updatedIds });
    setShowChat(true);
    setJoinTarget(null);
  };

  const handleBack = () => {
    setShowChat(false);
    setSelected(null);
  };

  useEffect(() => {
    if (showChat) document.body.classList.add('chat-open');
    else document.body.classList.remove('chat-open');
    return () => document.body.classList.remove('chat-open');
  }, [showChat]);

  const filtered = conversations.filter(c =>
    c.name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex h-full overflow-hidden min-h-0">
      {/* Sidebar */}
      <div className={`${showChat ? 'hidden md:flex' : 'flex'} flex-col w-full md:w-80 lg:w-96 border-r border-white/8 bg-black/20 h-full min-h-0 overflow-hidden`}>

        {filtered.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-3 text-center p-6">
            <div className="w-14 h-14 rounded-2xl bg-purple-500/10 flex items-center justify-center">
              <Users size={24} className="text-neon-purple" />
            </div>
            <p className="text-sm text-muted-foreground">Aucun groupe pour l'instant</p>
          </div>
        ) : (
          <ConversationList conversations={filtered} selected={selected} onSelect={handleSelect} user={user} />
        )}
      </div>

      {/* Chat */}
      <div className={`${showChat ? 'fixed inset-0 z-[200] flex md:relative md:inset-auto md:z-auto' : 'hidden md:flex'} flex-1 flex-col min-h-0 min-w-0`} style={showChat ? {background: 'hsl(230, 25%, 5%)'} : {}}>
        {selected ? (
            <ChatWindow conversation={selected} user={user} onBack={handleBack} isDm={false} onReadConversation={markConversationAsRead} />
         ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex-1 flex flex-col items-center justify-center gap-4 text-center p-8">
            <div className="w-20 h-20 rounded-3xl bg-purple-500/10 flex items-center justify-center neon-purple">
              <Users size={32} className="text-neon-purple" />
            </div>
            <h2 className="text-xl font-bold gradient-text">Sélectionnez un groupe</h2>
            <p className="text-sm text-muted-foreground max-w-xs">Choisissez un groupe pour commencer à discuter.</p>
          </motion.div>
        )}
      </div>

      {joinTarget && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setJoinTarget(null)} />
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
            className="relative glass-strong rounded-2xl border border-white/10 p-6 max-w-sm w-full z-10 flex flex-col items-center gap-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-purple-500/10 flex items-center justify-center">
              <Users size={24} className="text-neon-purple" />
            </div>
            <div>
              <h3 className="text-base font-bold text-foreground mb-1">Rejoindre le groupe</h3>
              <p className="text-sm text-muted-foreground">Voulez-vous rejoindre <span className="text-foreground font-semibold">{joinTarget.name}</span> ?</p>
            </div>
            <div className="flex gap-3 w-full">
              <button onClick={() => setJoinTarget(null)}
                className="flex-1 py-2.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-sm font-medium text-muted-foreground transition-all">
                Annuler
              </button>
              <button onClick={handleJoin} disabled={joining}
                className="flex-1 py-2.5 rounded-xl border border-primary/30 bg-primary/15 hover:bg-primary/25 text-sm font-medium text-primary transition-all disabled:opacity-50 flex items-center justify-center gap-2">
                {joining ? <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /> : null}
                Rejoindre
              </button>
            </div>
          </motion.div>
        </div>
      )}

      <NewConversationModal isOpen={showModal} onClose={() => setShowModal(false)} type="group" user={user} onCreate={(conv) => { setConversations(p => [conv, ...p]); setSelected(conv); setShowChat(true); }} />
    </div>
  );
}