import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { User, Mail, Save, Loader2, LogOut, Shield, Bell, Palette, ChevronRight, CheckCircle2, Download, Smartphone, Share, MoreHorizontal } from 'lucide-react';
import { toast } from 'sonner';

export default function Settings() {
  const [user, setUser] = useState(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ full_name: '', email: '' });
  const [installPrompt, setInstallPrompt] = useState(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showIosGuide, setShowIosGuide] = useState(false);

  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isAndroid = /android/i.test(navigator.userAgent);

  useEffect(() => {
    if (window.matchMedia('(display-mode: standalone)').matches) { setIsInstalled(true); return; }
    const handler = (e) => { e.preventDefault(); setInstallPrompt(e); };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (isIos) { setShowIosGuide(v => !v); return; }
    if (!installPrompt) {
      toast.error('Installation non disponible sur ce navigateur');
      return;
    }
    try {
      installPrompt.prompt();
      const { outcome } = await installPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setInstallPrompt(null);
        toast.success('Application installée !');
      }
    } catch (err) {
      toast.error('Erreur lors de l\'installation');
    }
  };

  const showInstallSection = !isInstalled && (installPrompt || isIos || isAndroid);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setForm({ full_name: u.full_name || '', email: u.email || '' });
    });
  }, []);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await base44.auth.updateMe({ full_name: form.full_name });
      toast.success('Profil mis à jour !');
    } catch {
      toast.error('Erreur lors de la sauvegarde');
    } finally {
      setSaving(false);
    }
  };

  const quickSettings = [
    { icon: Bell, label: 'Notifications', desc: 'Gérer les alertes', color: 'text-neon-purple', bg: 'bg-purple-500/10' },
    { icon: Shield, label: 'Confidentialité', desc: 'Contrôler vos données', color: 'text-neon-cyan', bg: 'bg-cyan-500/10' },
    { icon: Palette, label: 'Apparence', desc: 'Thème et couleurs', color: 'text-neon-pink', bg: 'bg-pink-500/10' },
  ];

  return (
    <div className="px-4 sm:px-6 md:px-8 pt-0 pb-24 md:pb-8 max-w-xl mx-auto overflow-y-auto overflow-x-hidden h-full w-full" style={{scrollbarWidth: 'none', msOverflowStyle: 'none'}}>
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-6 sticky top-0 z-10 glass-strong py-3 -mx-4 sm:-mx-6 md:-mx-8 px-4 sm:px-6 md:px-8">
        <div className="flex items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">Personnalisez votre compte</p>
          <button onClick={() => base44.auth.logout()}
            className="flex items-center gap-2 px-3 py-2 rounded-xl border border-white/8 bg-white/5 hover:bg-red-500/10 hover:border-red-500/30 hover:text-red-400 text-muted-foreground text-sm font-medium transition-all shrink-0">
            Se déconnecter <LogOut size={14} />
          </button>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
        className="glass rounded-2xl p-5 border border-white/8 mb-6">
        <div className="flex items-center gap-4 mb-2">
          <div className="w-14 h-14 rounded-2xl bg-primary/15 border border-primary/20 flex items-center justify-center text-xl font-bold text-primary">
            {user?.full_name?.charAt(0)?.toUpperCase() || user?.email?.charAt(0)?.toUpperCase() || '?'}
          </div>
          <div>
            <p className="font-semibold text-foreground">{user?.full_name || 'Utilisateur'}</p>
            <p className="text-sm text-muted-foreground">{user?.email}</p>
            <div className="flex items-center gap-1 mt-1">
              <CheckCircle2 size={12} className="text-green-400" />
              <p className="text-xs text-green-300">Connecté</p>
            </div>
          </div>
        </div>
      </motion.div>

      <motion.form initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
        onSubmit={handleSave} className="glass rounded-2xl p-6 border border-white/8 mb-6 space-y-4">
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <User size={16} className="text-neon-purple" /> Mon profil
        </h2>
        <div>
          <label className="block text-xs text-muted-foreground mb-1.5 font-medium">Nom complet</label>
          <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus-within:border-primary/50 transition-all">
            <User size={14} className="text-muted-foreground shrink-0" />
            <input type="text" value={form.full_name} onChange={e => set('full_name', e.target.value)}
              placeholder="Votre nom" className="flex-1 bg-transparent text-sm text-foreground placeholder-muted-foreground outline-none" />
          </div>
        </div>
        <div>
          <label className="block text-xs text-muted-foreground mb-1.5 font-medium">Email</label>
          <div className="flex items-center gap-3 bg-white/5 border border-white/8 rounded-xl px-4 py-3">
            <Mail size={14} className="text-muted-foreground shrink-0" />
            <p className="text-sm text-muted-foreground">{form.email}</p>
          </div>
        </div>
        <motion.button type="submit" disabled={saving} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}
          className="w-full py-3 rounded-xl border border-primary/30 bg-primary/10 hover:bg-primary/15 text-foreground font-semibold text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50 relative overflow-hidden">
          <div className="absolute inset-0 animate-shimmer" />
          {saving ? <><Loader2 size={16} className="animate-spin" /> Sauvegarde...</> : <><Save size={16} /> Sauvegarder</>}
        </motion.button>
      </motion.form>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
        className="glass rounded-2xl border border-white/8 overflow-hidden mb-6">
        <div className="px-5 py-4 border-b border-white/8">
          <h2 className="text-sm font-semibold text-foreground">Préférences</h2>
        </div>
        {quickSettings.map((item, i) => (
          <button key={i} className="w-full flex items-center gap-3 px-5 py-4 hover:bg-white/5 transition-all border-b border-white/5 last:border-0 text-left">
            <div className={`w-9 h-9 rounded-xl ${item.bg} flex items-center justify-center shrink-0`}>
              <item.icon size={16} className={item.color} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">{item.label}</p>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </div>
            <ChevronRight size={14} className="text-muted-foreground" />
          </button>
        ))}
      </motion.div>

      {(showInstallSection || isInstalled) && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="glass rounded-2xl border border-white/8 overflow-hidden mb-6">
          <div className="px-5 py-4 border-b border-white/8">
            <h2 className="text-sm font-semibold text-foreground">Application</h2>
          </div>
          <div className="px-5 py-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Smartphone size={16} className="text-neon-purple" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Installer l'application</p>
              <p className="text-xs text-muted-foreground">Accès rapide depuis votre écran d'accueil</p>
            </div>
            {isInstalled ? (
              <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-green-500/10 border border-green-500/20">
                <CheckCircle2 size={13} className="text-green-400" />
                <span className="text-xs text-green-300 font-medium">Installée</span>
              </div>
            ) : (
              <button onClick={handleInstall}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-primary/15 border border-primary/30 hover:bg-primary/25 text-sm font-medium text-primary transition-all">
                <Download size={14} /> Installer
              </button>
            )}
          </div>
          {isIos && showIosGuide && (
            <div className="px-5 pb-4 space-y-2">
              <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-muted-foreground space-y-2">
                <p className="font-semibold text-foreground">Comment installer sur iOS :</p>
                <p>1. Appuyez sur l'icône <span className="text-neon-cyan font-bold">Partager</span> (carré avec flèche) en bas de Safari</p>
                <p>2. Faites défiler et appuyez sur <span className="text-neon-cyan font-bold">« Sur l'écran d'accueil »</span></p>
                <p>3. Confirmez en appuyant sur <span className="text-neon-cyan font-bold">« Ajouter »</span></p>
              </div>
            </div>
          )}
        </motion.div>
      )}

      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}
        className="text-center text-xs text-muted-foreground">
        The Legends Online · v1.0
      </motion.p>
    </div>
  );
}