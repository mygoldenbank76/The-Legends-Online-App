import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';

export function useNotifications(user) {
  const [unreadByConversation, setUnreadByConversation] = useState({});

  const markConversationAsRead = useCallback((conversationId) => {
    setUnreadByConversation(prev => {
      const updated = { ...prev };
      delete updated[conversationId];
      return updated;
    });
  }, []);

  useEffect(() => {
    if (!user?.email) return;

    const loadUnreadMessages = async () => {
      const messages = await base44.entities.Message.list('-created_date', 1000);
      
      const unreadByConv = {};
      messages.forEach(msg => {
        if (msg.sender_email !== user.email) {
          unreadByConv[msg.conversation_id] = (unreadByConv[msg.conversation_id] || 0) + 1;
        }
      });

      setUnreadByConversation(unreadByConv);
    };

    loadUnreadMessages();
  }, [user?.email]);

  // Compute counts from unreadByConversation
  const unreadCount = Object.values(unreadByConversation).reduce((a, b) => a + b, 0);
  const unreadGroupCount = 0; // Simplified - just count total
  const unreadDmCount = unreadCount;

  return {
    unreadCount,
    unreadGroupCount,
    unreadDmCount,
    unreadByConversation,
    markConversationAsRead
  };
}