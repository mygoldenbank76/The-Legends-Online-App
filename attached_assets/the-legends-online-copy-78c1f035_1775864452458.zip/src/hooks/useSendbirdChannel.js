import { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { getOrInitSendbird } from '@/lib/sendbird';
import { GroupChannelHandler } from '@sendbird/chat/groupChannel';

// Module-level caches for instant display
let authCache = null;
const messagesCache = new Map(); // convId -> messages[]
const channelCache = new Map();  // convId -> SBChannel

export function useSendbirdChannel(conversation, user) {
  const [messages, setMessages] = useState(() => messagesCache.get(conversation?.id) || []);
  const [loading, setLoading] = useState(!messagesCache.has(conversation?.id));
  const [typingUsers, setTypingUsers] = useState([]);
  const prevConvIdRef = useRef(null);
  const [myUserId, setMyUserId] = useState(null);
  const channelRef = useRef(null);
  const myUserIdRef = useRef(null);
  const handlerIdRef = useRef(null);
  const sbRef = useRef(null);
  const toAppMessageRef = useRef(null);
  const queryRef = useRef(null);
  const [canLoadMore, setCanLoadMore] = useState(true);

  const toAppMessage = (sbMsg) => {
    const messageType = sbMsg.messageType;
    let type = 'text';
    if (messageType === 'file') {
      const mime = sbMsg.mimeType || sbMsg.type || '';
      if (mime.startsWith('image/')) type = 'image';
      else if (mime.startsWith('video/')) type = 'video';
      else if (mime.startsWith('audio/')) type = 'audio';
      else type = 'file';
    }
    return {
      id: String(sbMsg.messageId),
      conversation_id: conversation?.id,
      sender_email: sbMsg.sender?.metaData?.email || sbMsg.sender?.userId || '',
      sender_name: sbMsg.sender?.nickname || '',
      content: sbMsg.message || '',
      type,
      file_url: sbMsg.url || null,
      file_name: sbMsg.name || null,
      created_date: new Date(sbMsg.createdAt).toISOString(),
      is_edited: sbMsg.updatedAt > sbMsg.createdAt,
      is_deleted: false,
      reactions: (sbMsg.reactions || []).reduce((acc, r) => {
        const uids = r.userIds || r.user_ids || [];
        if (uids.length > 0) acc[r.key] = uids;
        return acc;
      }, {}),
      reply_to_id: sbMsg.parentMessageId ? String(sbMsg.parentMessageId) : null,
      reply_to_content: sbMsg.parentMessage?.message || null,
      reply_to_sender: sbMsg.parentMessage?.sender?.nickname || null,
      _sbMessage: sbMsg,
      _sbSenderId: sbMsg.sender?.userId || '',
      _parentMessageData: sbMsg.parentMessage ? { id: String(sbMsg.parentMessage.messageId), content: sbMsg.parentMessage.message, sender: sbMsg.parentMessage.sender?.nickname } : null,
    };
  };

  // Stable toAppMessage via ref
  toAppMessageRef.current = toAppMessage;

  const getOrCreateChannel = useCallback(async (sb, conv, currentUser) => {
    const channelUrl = `legends_${conv.id}`;

    let ch;
    try {
      ch = await sb.groupChannel.getChannel(channelUrl);
    } catch {
      const memberIds = conv.member_emails || [currentUser.email];
      const params = {
        channelUrl,
        name: conv.name || 'Chat',
        isDistinct: conv.type === 'direct',
        invitedUserIds: memberIds,
        isPublic: conv.type === 'group',
      };
      ch = await sb.groupChannel.createChannel(params);
    }

    // For public group channels, always join to ensure membership
    if (conv.type === 'group' && ch.isPublic) {
      try { await ch.join(); } catch { /* already member */ }
    }

    return ch;
  }, []);

  useEffect(() => {
    if (!conversation?.id || !user?.email) return;

    let isMounted = true;

    const init = async () => {
      const isNewConv = prevConvIdRef.current !== conversation.id;
      prevConvIdRef.current = conversation.id;

      // Show cached messages instantly
      const cached = messagesCache.get(conversation.id);
      if (cached) {
        setMessages(cached);
        setLoading(false);
      } else if (isNewConv) {
        setMessages([]);
        setLoading(true);
      }

      try {
        // Reuse auth if already fetched
        if (!authCache) {
          const authRes = await base44.functions.invoke('sendbirdAuth', {});
          authCache = authRes.data;
        }
        const { userId, appId, accessToken } = authCache;

        const sb = await getOrInitSendbird(userId, appId, accessToken);
        sbRef.current = sb;
        myUserIdRef.current = userId;
        setMyUserId(userId);

        // Use cached channel if available to skip network round-trip
        let ch = channelCache.get(conversation.id);
        if (!ch) {
          ch = await getOrCreateChannel(sb, conversation, user);
          channelCache.set(conversation.id, ch);
        }
        if (!isMounted) return;
        channelRef.current = ch;

        const query = ch.createPreviousMessageListQuery({ limit: 100, reverse: false, includeReactions: true, includeParentMessageText: true });
        queryRef.current = query;
        const prevMsgs = await query.load();
        
        // Ensure parent messages are loaded for thread replies
        for (const msg of prevMsgs) {
          if (msg.parentMessageId && !msg.parentMessage) {
            try {
              const results = await ch.getMessagesByMessageId(msg.parentMessageId, { prevResultSize: 0, nextResultSize: 0, includeReactions: true });
              if (results?.[0]) msg.parentMessage = results[0];
            } catch (e) { /* ignore if parent not found */ }
          }
        }
        if (isMounted) {
          const mapped = prevMsgs.map(toAppMessage);
          messagesCache.set(conversation.id, mapped);
          setMessages(mapped);
          setLoading(false);
          setCanLoadMore(prevMsgs.length === 100);
        }

        // Real-time handler
        const handlerId = `handler_${conversation.id}`;
        handlerIdRef.current = handlerId;
        const handler = new GroupChannelHandler({
          onMessageReceived: (_, msg) => {
            if (!isMounted) return;
            const convId = conversation.id;
            setMessages(prev => {
              const tempIdx = prev.findIndex(m => m._tempId && m.content === msg.message && m._sbSenderId === msg.sender?.userId);
              const realMsg = toAppMessageRef.current(msg);
              let next;
              if (tempIdx !== -1) {
                next = [...prev];
                next[tempIdx] = realMsg;
              } else {
                const exists = prev.find(m => m.id === String(msg.messageId));
                if (exists) return prev;
                next = [...prev, realMsg];
              }
              messagesCache.set(convId, next);
              return next;
            });
          },
          onMessageUpdated: (_, msg) => {
            if (!isMounted) return;
            setMessages(prev => prev.map(m => m.id === String(msg.messageId) ? toAppMessage(msg) : m));
          },
          onMessageDeleted: (_, msgId) => {
            if (!isMounted) return;
            setMessages(prev => prev.map(m => m.id === String(msgId) ? { ...m, is_deleted: true } : m));
          },
          onReactionUpdated: (_, event) => {
            if (!isMounted) return;
            const key = event.key;
            const convId = conversation.id;
            setMessages(prev => {
              const next = prev.map(m => {
                if (m.id !== String(event.messageId)) return m;
                const reactions = { ...m.reactions };
                if (event.operation === 'add') {
                  if (!reactions[key]) reactions[key] = [];
                  if (!reactions[key].includes(event.userId)) reactions[key] = [...reactions[key], event.userId];
                } else {
                  reactions[key] = (reactions[key] || []).filter(u => u !== event.userId);
                }
                return { ...m, reactions };
              });
              messagesCache.set(convId, next);
              return next;
            });
          },
          onTypingStatusUpdated: (channel) => {
            if (!isMounted) return;
            const typers = channel.getTypingUsers();
            setTypingUsers(typers.map(u => u.nickname || u.userId));
          },
        });
        sb.groupChannel.addGroupChannelHandler(handlerId, handler);
      } catch (err) {
        console.error('Sendbird init error:', err);
        authCache = null;
        if (isMounted) setLoading(false);
      }
    };

    init();

    return () => {
      isMounted = false;
      if (sbRef.current && handlerIdRef.current) {
        sbRef.current.groupChannel.removeGroupChannelHandler(handlerIdRef.current);
      }
    };
  }, [conversation?.id, user?.email]);

  const sendTextMessage = useCallback(async (content, replyTo = null) => {
    const ch = channelRef.current;
    if (!ch) return;

    // Optimistic message
    const tempId = `temp_${Date.now()}`;
    const optimistic = {
      id: tempId,
      _tempId: tempId,
      conversation_id: conversation?.id,
      sender_email: user?.email || '',
      sender_name: user?.full_name || user?.email?.split('@')[0] || '',
      content,
      type: 'text',
      file_url: null,
      file_name: null,
      created_date: new Date().toISOString(),
      is_edited: false,
      is_deleted: false,
      reactions: {},
      reply_to_id: replyTo?._sbMessage ? String(replyTo._sbMessage.messageId) : null,
      reply_to_content: replyTo?.content || null,
      reply_to_sender: replyTo?.sender_name || null,
      _sbMessage: null,
      _sbSenderId: myUserIdRef.current || '',
    };
    setMessages(prev => {
      const next = [...prev, optimistic];
      messagesCache.set(conversation?.id, next);
      return next;
    });

    const params = { message: content };
    if (replyTo?._sbMessage) params.parentMessageId = replyTo._sbMessage.messageId;
    const sentMsg = await new Promise((resolve, reject) => {
      ch.sendUserMessage(params).onSucceeded(resolve).onFailed(reject);
    });
    // Replace optimistic with real message
    setMessages(prev => {
      const idx = prev.findIndex(m => m._tempId === tempId);
      const realMsg = toAppMessageRef.current(sentMsg);
      realMsg._sbSenderId = myUserIdRef.current || realMsg._sbSenderId;
      let next;
      if (idx !== -1) {
        next = [...prev];
        next[idx] = realMsg;
      } else {
        const exists = prev.find(m => m.id === String(sentMsg.messageId));
        next = exists ? prev : [...prev, realMsg];
      }
      messagesCache.set(conversation?.id, next);
      return next;
    });
  }, [conversation?.id, user]);

  const sendFileMessage = useCallback(async (file) => {
    const ch = channelRef.current;
    if (!ch) throw new Error('Canal non disponible');
    const sentMsg = await new Promise((resolve, reject) => {
      ch.sendFileMessage({ file, fileName: file.name, mimeType: file.type }).onSucceeded(resolve).onFailed(reject);
    });
    setMessages(prev => {
      const exists = prev.find(m => m.id === String(sentMsg.messageId));
      if (exists) return prev;
      const mapped = [...prev, toAppMessageRef.current(sentMsg)];
      messagesCache.set(conversation.id, mapped);
      return mapped;
    });
  }, [conversation?.id]);

  const editMessage = useCallback(async (msg, newContent) => {
    const ch = channelRef.current;
    if (!ch || !msg._sbMessage) return;
    // Optimistic update
    setMessages(prev => {
      const next = prev.map(m => m.id === msg.id ? { ...m, content: newContent, is_edited: true } : m);
      messagesCache.set(conversation.id, next);
      return next;
    });
    await ch.updateUserMessage(msg._sbMessage.messageId, { message: newContent });
  }, [conversation?.id]);

  const deleteMessage = useCallback(async (msg) => {
    const ch = channelRef.current;
    if (!ch || !msg._sbMessage) return;
    await ch.deleteMessage(msg._sbMessage);
  }, []);

  const startTyping = useCallback(() => {
    channelRef.current?.startTyping();
  }, []);

  const endTyping = useCallback(() => {
    channelRef.current?.endTyping();
  }, []);

  const reactToMessage = useCallback(async (msg, emoji) => {
    const ch = channelRef.current;
    if (!ch) return;
    const existing = msg.reactions?.[emoji] || [];
    const userId = myUserIdRef.current;
    try {
      const results = await ch.getMessagesByMessageId(parseInt(msg.id), {
        prevResultSize: 1,
        nextResultSize: 0,
        includeReactions: true,
      });
      const target = results?.find(m => String(m.messageId) === msg.id) || msg._sbMessage;
      if (!target) { console.error('reactToMessage: message not found', msg.id); return; }
      if (Array.isArray(existing) && existing.includes(userId)) {
        await ch.deleteReaction(target, emoji);
      } else {
        await ch.addReaction(target, emoji);
      }
    } catch (err) {
      console.error('reactToMessage error:', err);
    }
  }, []);

  const loadMoreMessages = useCallback(async () => {
    if (!queryRef.current || !canLoadMore) return;
    try {
      const olderMsgs = await queryRef.current.load();
      if (olderMsgs.length === 0) {
        setCanLoadMore(false);
        return;
      }
      // Ensure parent messages are loaded
      for (const msg of olderMsgs) {
        if (msg.parentMessageId && !msg.parentMessage) {
          try {
            const results = await channelRef.current.getMessagesByMessageId(msg.parentMessageId, { prevResultSize: 0, nextResultSize: 0, includeReactions: true });
            if (results?.[0]) msg.parentMessage = results[0];
          } catch (e) { /* ignore */ }
        }
      }
      setMessages(prev => {
        const mapped = olderMsgs.map(toAppMessageRef.current);
        const next = [...mapped, ...prev];
        messagesCache.set(conversation?.id, next);
        return next;
      });
      setCanLoadMore(olderMsgs.length === 100);
    } catch (err) {
      console.error('Load more error:', err);
    }
  }, [canLoadMore, conversation?.id]);

  return {
    messages,
    loading,
    typingUsers,
    channel: channelRef.current,
    myUserId: myUserIdRef.current || myUserId,
    sendTextMessage,
    sendFileMessage,
    editMessage,
    deleteMessage,
    reactToMessage,
    startTyping,
    endTyping,
    loadMoreMessages,
    canLoadMore,
    refetchMessages: () => {},
  };
}