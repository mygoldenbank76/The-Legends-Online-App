import { useEffect, useState, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';

export function useMessageSync(conversationId) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const unsubscribeRef = useRef(null);

  const refetchMessages = useCallback(async () => {
    if (!conversationId) return;
    try {
      const msgs = await base44.entities.Message.filter(
        { conversation_id: conversationId },
        'created_date',
        1000
      );
      setMessages(msgs || []);
    } catch (err) {
      console.error('Refetch error:', err);
    }
  }, [conversationId]);

  useEffect(() => {
    if (!conversationId) {
      setMessages([]);
      setLoading(false);
      return;
    }

    let isMounted = true;

    const init = async () => {
      try {
        setLoading(true);
        
        // Fetch initial messages
        const initialMessages = await base44.entities.Message.filter(
          { conversation_id: conversationId },
          'created_date',
          1000
        );
        
        if (isMounted) {
          setMessages(initialMessages || []);
        }

        // Subscribe to real-time updates
        unsubscribeRef.current = base44.entities.Message.subscribe((event) => {
          if (!isMounted || event.data?.conversation_id !== conversationId) return;

          setMessages(prev => {
            const messageIds = new Set(prev.map(m => m.id));
            
            if (event.type === 'create' && !messageIds.has(event.id)) {
              return [...prev, event.data];
            }
            
            if (event.type === 'update') {
              return prev.map(m => m.id === event.id ? event.data : m);
            }
            
            if (event.type === 'delete') {
              return prev.filter(m => m.id !== event.id);
            }
            
            return prev;
          });
        });

      } catch (err) {
        console.error('Messages sync error:', err);
        if (isMounted) setMessages([]);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    init();

    return () => {
      isMounted = false;
      if (unsubscribeRef.current) {
        unsubscribeRef.current();
      }
    };
  }, [conversationId]);

  return { messages, loading, refetchMessages };
}