import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { email } = await req.json();
    if (!email) return Response.json({ error: 'email required' }, { status: 400 });

    const users = await base44.asServiceRole.entities.User.filter({ email });
    if (!users || users.length === 0) return Response.json({ error: 'User not found' }, { status: 404 });

    return Response.json({ userId: users[0].id, nickname: users[0].full_name || email.split('@')[0] });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});