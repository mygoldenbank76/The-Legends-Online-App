import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

const SENDBIRD_APP_ID = Deno.env.get('SENDBIRD_APP_ID');
const SENDBIRD_API_TOKEN = Deno.env.get('SENDBIRD_API_TOKEN');
const BASE_URL = `https://api-${SENDBIRD_APP_ID}.sendbird.com/v3`;

const headers = {
  'Content-Type': 'application/json',
  'Api-Token': SENDBIRD_API_TOKEN,
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const userId = user.id; // Use Base44 user ID (no email allowed as SB user_id)
    const nickname = user.full_name || user.email.split('@')[0];
    const encodedId = encodeURIComponent(userId);

    // Step 1: Check if user exists
    const checkRes = await fetch(`${BASE_URL}/users/${encodedId}`, { headers });

    if (!checkRes.ok) {
      // Create user with access token
      const createRes = await fetch(`${BASE_URL}/users`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          user_id: userId,
          nickname,
          profile_url: '',
          issue_access_token: true,
        }),
      });
      if (!createRes.ok) {
        const err = await createRes.text();
        throw new Error(`Create user failed: ${createRes.status} ${err}`);
      }
      const created = await createRes.json();
      return Response.json({ userId, accessToken: created.access_token, appId: SENDBIRD_APP_ID });
    }

    // Step 2: User exists - update nickname and issue new token
    const updateRes = await fetch(`${BASE_URL}/users/${encodedId}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ nickname, issue_access_token: true }),
    });
    if (!updateRes.ok) {
      const err = await updateRes.text();
      throw new Error(`Update user failed: ${updateRes.status} ${err}`);
    }
    const updated = await updateRes.json();

    // If access_token not returned from update, issue via token endpoint
    let accessToken = updated.access_token;
    if (!accessToken) {
      const tokenRes = await fetch(`${BASE_URL}/users/${encodedId}/token`, {
        method: 'POST',
        headers,
        body: JSON.stringify({}),
      });
      if (!tokenRes.ok) {
        const err = await tokenRes.text();
        throw new Error(`Token issue failed: ${tokenRes.status} ${err}`);
      }
      const tokenData = await tokenRes.json();
      accessToken = tokenData.token;
    }

    return Response.json({ userId, accessToken, appId: SENDBIRD_APP_ID });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});