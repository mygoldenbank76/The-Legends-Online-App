import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { accessToken } = await base44.asServiceRole.connectors.getConnection('github');
    const { owner, repo } = await req.json();

    if (!owner || !repo) {
      return Response.json({ error: 'owner and repo are required' }, { status: 400 });
    }

    const response = await fetch(`https://api.github.com/repos/${owner}/${repo}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/vnd.github+json',
      },
    });

    if (!response.ok) {
      return Response.json({ error: 'Repository not found' }, { status: 404 });
    }

    const repoData = await response.json();

    return Response.json({
      name: repoData.name,
      description: repoData.description,
      url: repoData.html_url,
      stars: repoData.stargazers_count,
      forks: repoData.forks_count,
      language: repoData.language,
      updated_at: repoData.updated_at,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});